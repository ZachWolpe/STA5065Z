rm(list = ls())

# Median distance to origin:
f  = function(N,d)
{
   return((1-0.5^(1/N))^(1/d))
}

# Evaluate median distance for increasing d under different data set sizes.
# Calculate in terms of order of dataset size:
d  = 1:100
orders = 10
nn = rep(10^{1:orders},length(d))
dd = rep(d,each = orders)

Z = matrix(f(nn,dd),orders,length(d))
cols = c('green','yellow','blue')
filled.contour(1:orders,d,Z,plot.axes = {contour(1:orders,d,Z,add = T);axis(2);axis(1,labels = paste0('10^',1:orders),at = 1:orders)},color.palette = colorRampPalette(cols))


# Evaluate in terms of N directly:
d  = 1:100
n  = seq(10,10^3,length = 100)
nn = rep(n,length(d))
dd = rep(d,each = length(n))
Z = matrix(f(nn,dd),length(n),length(d))
filled.contour(n,d,Z,plot.axes = {contour(n,d,Z,add = T);axis(2);axis(1)},color.palette = colorRampPalette(cols),xlab = 'N',ylab = 'd')

