rm(list = ls())
library(MASS)
library(pls)
data(mayonnaise)
attach( mayonnaise)
X = NIR
Y = oil.type
DAT = cbind(Y,NIR)
colnames(DAT) = c('Y',paste0('X',1:dim(NIR)[2]))
DAT = data.frame(DAT)
res = lda(Y~.,data = DAT)
centroids = res$means

pred=predict(res)

par(mfrow=c(1,1))
plot(pred$x[,2]~pred$x[,2], col = Y)


