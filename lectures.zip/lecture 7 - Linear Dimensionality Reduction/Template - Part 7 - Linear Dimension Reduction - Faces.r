rm(list = ls())
library(pixmap)

x=read.pnm(file = "Face_Data/1.pgm")

m  = prod(x@size)
n  = 400
xx =t(matrix(rev(x@grey),x@size[1],x@size[2]))
image(xx)
dims = x@size


X = matrix(0,n,prod(x@size))
for(i in 1:n)
{
  x=read.pnm(file = paste0("Face_Data/",i,".pgm"))
  X[i,] = rev(x@grey)
}
X = apply(X,2,scale)

cols = colorRampPalette(c('grey90','grey50','grey10'))
windows()
par(mfrow = c(3,3))
for(j in 1:39)
{
 sss = 1:9 +j*10
 Sys.sleep(0.25)
 for( i in sss){
 image(t(matrix(X[i,],dims[1],dims[2])),col = cols(20),main = paste0('Individual',j)) }
}

# Calculate Eigenvalues:	
N   = ...
SIG = ...
sv  = ...

# Construct components:
temp  = ...
temp = temp*matrix(...,dim(X)[2],dim(X)[1],byrow = T)

windows()
par(mfrow = c(3,3))
for(i in 1:9)
{
   image(t(matrix(temp[,i],dims[1],dims[2])),col = cols(20))
}



#windows()
# How much information?
plot(cumsum(sv$values)/sum(sv$values),type = 'l')
abline(h = 0.95, lty = 3)

ss = c(10,50,100,200,350)
abline(v = ss,lty = 3)

ii = 36*10+1 #26

#windows()
# Compare construction to full image:
par(mfrow = c(2,5))
for(i in ss)
{
  Sys.sleep(0.01)
  Yhat = ...  
  image(t(matrix(Yhat,dims[1],dims[2])),col = cols(20))
  Sys.sleep(0.01)
}
for( i in ss){
image(t(matrix(X[ii,],dims[1],dims[2])),col = cols(20)) }
