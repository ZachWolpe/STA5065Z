rm(list = ls())
library(ISLR)
library(pls)
data(Hitters)
attach(Hitters)
X = model.matrix(Salary~., data = Hitters)[,-1]
X = X[,-c(14,15,19)]
Y = Salary
index = !is.na(Y)
Y = scale(Y[index])
X = apply(X,2,scale)

pls = function(X,Y,M)
{
  p   = dim(X)[2]
  N   = dim(X)[1]
  PSI = matrix(0,M,p)
  B   = matrix(0,N,M)
  Y.  = Y
  X.  = X
  thetas = matrix(0,1,M)

  for(i in 1:M)
  {
   for(j in 1:p)
   {
      md       = lm(Y.~X.[,j])
      PSI[i,j] = coefficients(md)[2]
   }
   B[,i] = X.%*%PSI[i,]
   md = lm(Y.~B[,i])
   thetas[i] = coefficients(md)[2]
   Y. = residuals(md)

   for(j in 1:p)
   {
     md     = lm(X.[,j]~B[,i])
     X.[,j] = residuals(md)
   }
  }
  return(list(B=B,PSI=PSI, thetas = thetas ))
}

resa = pls(X,Y,2)


library(colorspace)
color.gradient = function(x, colors=c('green','red'), colsteps=50)
{
  colpal = colorRampPalette(colors)
  return( colpal(colsteps)[ findInterval(x, seq(min(x),max(x), length=colsteps)) ] )
}

resb = plsr(Salary~., data = Hitters[,-c(14,15,20)], scale = T, ncomp = 2, method = pls.options()$simpls)
par(mfrow = c(2,2))
plot(resa$B,pch = 16, col = color.gradient(Salary[index]))
plot(resb$scores[,1:2],pch = 16, col = color.gradient(Y))
resb$loadings
resa$PSI


