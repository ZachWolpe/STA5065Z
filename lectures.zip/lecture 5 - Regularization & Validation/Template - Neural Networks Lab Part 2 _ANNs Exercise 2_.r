rm(list = ls())

# Let's fake a dataset and see if the network evaluates:
set.seed(2019)
N = 50
x = runif(N,-1,1)
# y = sin(pi*x)
y = 2*x + sin(1.5*pi*x) + rnorm(N,0,1.2)
plot(y~x, pch = 1, frame=F, main='Data Generating Function', font.main=1,
     col='#821000')
lines(2*sort(x) + sin(1.5*pi*sort(x)) ~ sort(x), lty=2, col='blue')

# Get the data in matrix form:
X = matrix(x, ncol =1)
Y = matrix(y, ncol = 1)


# Specify activation functions for the hidden and output layers:
sig1 = function(x)
{
  # 1/(1+exp(-x))
  tanh(x)
}
sig2 = function(x)
{
  x
}

# Write a function that evaluates the neural network (forward recursion):
# X     - Input matrix (N x p)
# Y     - Output matrix(N x q)
# theta - A parameter vector (all of the parameters)
# m     - Number of nodes on hidden layer
# lam   - Regularisation parameter (see later)
neural_net = function(X,Y, theta, m, lam = 0)
{
	 # Relevant dimensional variables:
   N = dim(X)[1]
   p = dim(X)[2]
   q = dim(Y)[2]
   
   # Populate weight-matrix and bias vectors:
   index = 1:(p*m)
   W1    = matrix(theta[index], p, m)
   index = max(index)+1:(m*q)
   W2    = matrix(theta[index], m, q)
   index = max(index)+1:(m)
   b1    = matrix(theta[index],m,1)
   index = max(index)+1:(q)
   b2    = matrix(theta[index],q,1)
   

   
   # Evaluate network:
   out   = rep(0,N)
   error = rep(0,N)
   ones  = matrix(1,1,N)
   #for(i in 1:N)
   #{
      A0  = t(X)
      A1  = sig1(t(W1)%*%A0+b1%*%ones)
      A2  = sig2(t(W2)%*%A1+b2%*%ones)
      out = t(A2)
      error = (Y-t(A2))^2
   #}

   # Calculate error:
   E1 = mean(error)
   E2 = E1 + lam/N*(sum(W1^2) + sum(W2^2))
   
   # Return predictions and error:
   return(list(out = out, E1 = E1, E2 = E2))
}

# We need to know the number of parameters in the network:
p          = dim(X)[2]
q          = dim(Y)[2]
m          = 12
npars      = p*m+m*q+m+q
theta_rand = runif(npars,-1,1)
res = neural_net(X,Y,theta_rand,m,0)

plot(y~x,pch = 1,col = 'blue', frame=F, main='Neural Network: No Training', font.main=1)
points(res$out~x,pch = 4, col = 'red')
legend('topleft', c('Y','Predictions'), box.lwd = 0.1,
       pch = c(1,4), col = c('blue','red'))


# ---- No Regularization: Overfitting ----x
obj = function(pars)
{
  res = neural_net(X,Y,pars,m,0)
  return(res$E1)
}
obj(theta_rand)

# ---- optimize ----x
res_opt = nlm(obj,theta_rand, iterlim = 500)
res_opt

# fit model
res_fit = neural_net(X,Y,res_opt$estimate,m,0)

# visualize curve
XX  = matrix(seq(-1,1,length =100),ncol = 1)
YY  = XX*0
res_fit2 = neural_net(XX,YY,res_opt$estimate,m,0)

# ---- Fit: No Regularization ----x
plot(y~x,pch = 1, col = 'darkred',
     frame=F, main='Neural Net: No Regularization', font.main=1)
points(res_fit$out~x,pch = 1, col = 'lightblue')
lines(res_fit2$out~XX[,1], col='lightblue')




# ----- Validation: Regularization -----x
# Conduct a validation analysis:
set        = sample(1:N, 0.8*N, replace = F)
X_train    = matrix(X[set,], ncol=1)
Y_train    = matrix(Y[set,], ncol=1)
X_val      = matrix(X[-set,], ncol=1)
Y_val      = matrix(Y[-set,], ncol=1)

lambda=1
obj = function(pars)
{
  res = neural_net(X_train,Y_train, pars, m, lambda)
  return(res$E2)
}
obj(theta_rand)

M_seq   = 10
Train_E = rep(NA, M_seq)
Val_E   = rep(NA, M_seq)
lam     = exp(seq(-7, 0, length=M_seq))
for(i in 1:M_seq)
{
	# Optimise for constraint lam[i]
  # ---- optimize ----x
  lambda     = lam[i]
  theta_rand = runif(npars,-2, 2)
  res_opt    = nlm(obj, theta_rand, iterlim=500)
	
	# Calculate Validation Error:
  res_1      = neural_net(X_train, Y_train, res_opt$estimate, m, 0)
  res_2      = neural_net(X_val, Y_val, res_opt$estimate, m, 0)
  Train_E[i] = res_1$E1
  Val_E[i]   = res_2$E1
  print(paste('Iteration: ', i)) 
}
	
plot(Val_E~lam, type = 'l',col = 4, ylim = c(0,max(Val_E)))
points(Val_E~lam, type = 'b',col = 4, ylim = c(0,max(Val_E)))










# ----- prediction after regularization -----x
wh     = which.min(Val_E)
lambda = lam[wh]


theta_rand = runif(npars,-2, 2)
res_opt    = nlm(obj, theta_rand, iterlim=500)
res_fit    = neural_net(X,Y,res_opt$estimate,m,0)

# visualize curve
XX  = matrix(seq(-1,1,length =100),ncol = 1)
YY  = XX*0
res_fit2 = neural_net(XX,YY,res_opt$estimate,m,0)

# ---- Fit: No Regularization ----x
plot(y~x,pch = 1, col = 'darkred',
     frame=F, main=paste('Neural Net: Regularization  λ:', round(lambda, 3), 
                         sep=''), font.main=1)
points(res_fit$out~x,pch = 1, col = 'lightblue')
lines(res_fit2$out~XX[,1], col='lightblue')
lines(rfit2$out~XX[,1], col='red')
lines(2*sort(x) + sin(1.5*pi*sort(x)) ~ sort(x), lty=2, col='blue')






# ----------------------------- Visualize ∆µ -----------------------------x
lams <- seq(0,round(lam[wh], 3), length.out = 20)

for (l in lams) {
  # ---- optimize ----x
  lambda     = l
  theta_rand = runif(npars,-2, 2)
  res_opt    = nlm(obj, theta_rand, iterlim=500)
  
  # ---- fit ----x
  fit        = neural_net(XX, YY, res_opt$estimate, m, 0)
  
  # ---- visualized fit: vary regularization ----x
  plot(y~x,pch = 1, col = 'lightblue',
       frame=F, main=paste('Neural Net: Regularization  λ:', round(lambda, 3), 
                           sep=''), font.main=1)
  lines(fit$out~XX[,1], col='darkred')
  lines(2*sort(x) + sin(1.5*pi*sort(x)) ~ sort(x), lty=2, col='blue')
  legend('bottomright', 
         col=c('lightblue', 'darkred', 'blue'),
         legend = c('data', 'g(x)', 'target'),
         pch = c(1, NA, NA), lty = c(NA, 1, 2))
}





















