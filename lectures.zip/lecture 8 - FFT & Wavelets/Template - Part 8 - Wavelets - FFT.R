rm(list = ls(all = TRUE))

# Create two functions:
# Stationary:
# -------- Stationary --------x
m1 = function(s, alpha0, alpha, beta, f, sig)
{
   res = alpha0/2 + s*0
   for(i in 1:length(alpha))
   {
      print(res[1:5])
     res = res + 
        alpha[i]*cos(2*pi*f[i]*s) + 
        beta[i]*sin(2*pi*f[i]*s)
     print(res[1:5] + alpha[i]*cos(2*pi*f[i]*s)[1:5])
     print('------')
   }
   # Add some noise:
   res = res + rnorm(length(s), 0, sig)
   return(res)
}

# -------- Non-Stationary --------x
m2 = function(s, alpha0, alpha, beta, f, lower, upper, sig)
{
   res = alpha0/2 + s*0
   for(i in 1:length(alpha))
   {
      res = res + 
         (alpha[i]*cos(2*pi*f[i]*s) + 
         beta[i]*sin(2*pi*f[i]*s)) * 
         (s>=lower[i])*(s<upper[i])
   }
   # Add some noise:
   res = res + rnorm(length(s), 0, sig)
   return(res)
}

s = seq(0,1,1/200)


# ---- without noise ----x
par(mfrow = c(2,2))
y1_ = m1(s = s, alpha0 = 0, alpha = c(1,1,1,1), 
        beta = c(0,0,0,0), f = c(2,4,10,20), sig =0.0)
y2_ = m2(s,0,c(1,1,1,1),c(0,0,0,0),c(2,4,10,20),c(0.8,0.6,0.3,0),c(1,0.8,0.6,0.3),sig =0.0)
plot(y1_~s,type= 'l', frame=F, col='steelblue', main='No Noise', main.font=1)
plot(y2_~s,type= 'l', frame=F, col='steelblue', main='No Noise', main.font=1)

# ---- with noise ----x
y1 = m1(s,0,c(1,1,1,1),c(0,0,0,0),c(2,4,10,20),sig = 0.5)
y2 = m2(s,0,c(1,1,1,1),c(0,0,0,0),c(2,4,10,20),c(0.8,0.6,0.3,0),c(1,0.8,0.6,0.3),sig =0.5)
plot(y1~s,type= 'l', frame=F, col='#800000', main='With Noise', main.font=1)
plot(y2~s,type= 'l', frame=F, col='#800000', main='With Noise', main.font=1)



# Apply FFT and plot coefs:
res1 = fft(y1,inverse = F)
plot(Re(res1),xlim = c(0,200),type= 'h')
res2 = fft(y2,inverse = F)
plot(Re(res2),xlim = c(0,200),type= 'h')

# Note that we can actually reverse the process to recover the signal used to fit:
freq_to_signal = function(coefs, s)
{
  N   = length(s)
  i   = complex(real = 0, imaginary = 1)
  y   = rep(0,N)
  k   = 1:length(coefs)-1
  for(j in 1:N)
  {
    # Reconstruct series at each time point based on ALL the coefficients.
    y[j] <- sum(coefs*exp(i*2*pi*k*(j/N)))/N
  }
  return(y)
}

# Reverse to reconstruct
par(mfrow=c(1,1))
yhat1  = freq_to_signal(res1, s) # Note: Recreating Noise!
yhat1. = freq_to_signal(res1*(abs(res1)>20), s)
plot(y1~s,type ='l', frame=F, main='Signal 1', font.main=1)
lines(yhat1~s,lwd = 2, col = 'darkblue')
lines(yhat1.~s,lwd = 2, col = 'lightblue')
lines(y1_~s,lwd = 1, col = 'darkred')
legend('bottomright', 
       legend = c('signal + noise', 'target (noiseless)', 'full recon', 'thresholding'),
       col = c('black', 'darkred', 'darkblue', 'lightblue'),
       lty = c(1), 
       box.lwd = 0.2, cex=0.4)



# NOTE: great compression! 
plot(y1_~s, type ='l', col='darkred', frame=F, main='Signal', font.main=1)
lines(yhat1.~s,lwd = 2, col = 'steelblue')
legend('bottomright', 
       legend = c('signal', 'recon'),
       col = c('darkred', 'steelblue'),
       lty = c(1), 
       box.lwd = 0.2, cex=0.4)



# ---- Non-Stationary Series ----x
yhat2 = freq_to_signal(res2, s)
yhat2. = freq_to_signal(res2*(abs(res2)>20), s)
plot(y2~s,type ='l',col = 'lightgray', frame=F)
lines(yhat2.~s,lwd = 1, col = 'blue')
lines(m2(s,0,c(1,1,1,1),c(0,0,0,0),c(2,4,10,20),c(0.8,0.6,0.3,0),c(1,0.8,0.6,0.3),sig =0)~s, col='red')


 #=========================================================================
# DWT: Wavelets using: wmtsa
library("wmtsa")
?wavShrink
result = wavShrink(y2, threshold = 1)
plot(result, type='l')
lines(m2(s,0,c(1,1,1,1),c(0,0,0,0),c(2,4,10,20),c(0.8,0.6,0.3,0),c(1,0.8,0.6,0.3),sig =0), 
      col='red', lty=2)


#=========================================================================
# CWT: Wavelets using: wmtsa
library('WaveletComp')
?analyze.wavelet

# Time Series: Continuous Domain
res3 = analyze.wavelet(data.frame(y1), loess.span = 0, dt = diff(s)[1])
res4 = analyze.wavelet(data.frame(y2), loess.span = 0, dt = diff(s)[1])

# reconstruction
yhat3 = reconstruct(res3)
yhat4 = reconstruct(res4)


# Time Freq Analysis
wt.image(res3, color.key = 'interval', legend.params = list(lab='wavelet power levels'))


# stationary!
res3 = analyze.wavelet(data.frame(y1), loess.span = 0, dt = diff(s)[1], upperPeriod = 1)
wt.image(res3, color.key = 'interval', legend.params = list(lab='wavelet power levels'))


# non-stationary!
res4 = analyze.wavelet(data.frame(y2), loess.span = 0, dt = diff(s)[1], upperPeriod = 1)
wt.image(res4, color.key = 'interval', legend.params = list(lab='wavelet power levels'))



# create a new series
# -------- Non-Linear in Time --------x
m3 = function(s, alpha0, alpha, beta, f, sig)
{
   res = alpha0/2 + s*0
   for(i in 1:length(alpha))
   {
      res = res + 
         (alpha[i]*cos(2*pi*f[i]*sqrt(s)) + 
             beta[i]*sin(2*pi*f[i]*s))
   }
   # Add some noise:
   res = res + rnorm(length(s), 0, sig)
   return(res)
}


# evaluate 
y3 = m3(s, 0, c(1,1), c(0,0), c(4,10), 0.5)
plot.ts(y3)

# non-linear in Time
res5 = analyze.wavelet(data.frame(y3), loess.span = 0, dt = diff(s)[1], upperPeriod = 1)
wt.image(res5, color.key = 'interval', legend.params = list(lab='wavelet power levels'))



