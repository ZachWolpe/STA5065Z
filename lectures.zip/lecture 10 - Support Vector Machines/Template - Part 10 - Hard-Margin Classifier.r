rm(list= ls(all = TRUE))
# Fake some data:
N  = 200

# ---- generate data ----x
x1  = runif(N,-1,1)
x2  = runif(N,-1,1)
X   = cbind(x1,x2)
y   = c(-1,1)[(x2>=x1) + 1] # Encode responses as -1,1

plot(x2~x1,pch = c(1,16)[(y+1)/2+1], 
    col= c('darkred','steelblue')[(y+1)/2+1],
    main='Assuming Linearly Seperable', font.main=1, frame=F)

library('quadprog')
# Create data matrix:
X = cbind(x1,x2)
# Some space for the matrix in out QP problem.
DD = X %*% t(X)*0

# Assign inner products to D
n = dim(DD)[1]
for (i in 1:n) {
  for (j in 1:n) {
    DD[i,j] = y[i]*y[j]*t(X[i,])%*%X[j,]
  }
}
 
 
 # Assign inner products to D


 # D inverse is not a friendly chop... So we do what any respectable
 # applied mathematician does... We cheat (a little) by adding a small component
 # to the diagonal:
eps = 5e-6
DD  = DD + eps*diag(N)

# Now for the constraints:
# We have quality constraints and inequality constraints:
# Eq  :    y'a = 0
# Ineq:    a >= 0
Amat = cbind(y, diag(n)) # y will be on first row of t(Amat)
bvec = matrix(0, N+1, 1)
d    = matrix(1,N,1)

# Solve for lagrange mults a:
res = solve.QP(DD, d, Amat, bvec, meq = 1, factorized=F)
a   = res$solution

 



plot(a,type= 'h', main = expression(alpha[i]),
     xlab = expression(i), col='steelblue', frame=F, lwd=2)

# Recover the model:
ww =   t(a*y) %*% X
ww
par(mfrow = c(2,2))
par(mfrow = c(1,1))
plot(x2~x1,pch = c(1,16)[(y+1)/2+1])
plot(x2~x1,pch = c(1,16)[(y+1)/2+1], 
     col= c('darkred','steelblue')[(y+1)/2+1],
     main='Assuming Linearly Seperable', font.main=1, frame=F)


pad.a     = round(a, 3)
wh        = which.max(a)
abline(v=0,h = 0,lty = 2)

# How to find the intercept?..
intercept = (1/y[wh] - ww%*%X[wh,])
yhat      = sign(ww%*%t(X) + intercept[1])


# ---- view results -----x
par(mfrow = c(2,2))
plot(x2~x1,pch = c(1,16)[(y+1)/2+1], 
     col= c('darkred','steelblue')[(y+1)/2+1],
     main='True Classes', font.main=1, frame=F)
plot(x2~x1, pch = 16, 
     main='predictions', font.main=1, frame=F,
     col = c('grey','lightblue')[(yhat+1)/2+1])

wh.text = which(pad.a!=0)
points(x2~x1, pch = 1,col = c(NA,'red')[(pad.a>0)+1],cex=2)
text(x2[wh.text]~x1[wh.text],labels = paste0('n = ',wh.text))
plot(y*a,type = 'h')

# Package solution:
library('e1071')
par(mfrow = c(1,1))

dat    = data.frame(y=as.factor(y),x2=x2,x1=x1)
model  = svm(y~., data = dat, kernel ='linear',type = 'C', cost = 20000, scale = F)
plot(x2~x1,pch = c(1,16)[(y+1)/2+1])
points(x2~x1, pch = 1,col = c(NA,'red')[(pad.a>0)+1],cex=2)
points(model$SV[,1]~model$SV[,2],pch = '+', col = 'blue',cex = 2)
model
plot(model$coefs~model$index,type = 'h',xlim = c(0,N))





# ---------------------- NON LINEARLY: working in the Z-Space ----------------------x



# rm(list= ls(all = TRUE))
# Fake some data:
N  = 200

# ---- generate data ----x
x1  = runif(N,-1,1)
x2  = runif(N,-1,1)
X   = cbind(x1,x2)
y   = c(-1,1)[(x2>=x1) + 1] # Encode responses as -1,1
y   = c(-1,1)[(x2^2 + x1^2>=0.8^2) + 1] # Encode responses as -1,1

par(mfrow=c(1,1))
plot(x2~x1,pch = c(1,16)[(y+1)/2+1], 
     col= c('darkred','steelblue')[(y+1)/2+1],
     main='Assuming Linearly Seperable', font.main=1, frame=F)

library('quadprog')
# Create data matrix:
x = cbind(x1,x2)
X <- x




# Z space
z <- cbind(x1^2, x2^2)


# Some space for the matrix in out QP problem.
DD = X %*% t(X)*0

# Assign inner products to D
n <- dim(DD)[1]
for (i in 1:n) {
  for (j in 1:n) {
    DD[i,j] = y[i]*y[j]*t(z[i,])%*%z[j,]
  }
}




# Assign inner products to D


# D inverse is not a friendly chop... So we do what any respectable
# applied mathematician does... We cheat (a little) by adding a small component
# to the diagonal:
eps = 5e-6
DD  = DD + eps*diag(N)

# Now for the constraints:
# We have quality constraints and inequality constraints:
# Eq  :    y'a = 0
# Ineq:    a >= 0
Amat = cbind(y, diag(N)) # y will be on first row of t(Amat)
bvec = matrix(0, N+1, 1)
d    = matrix(1,N,1)

# Solve for lagrange mults a:
res = solve.QP(DD, d, Amat, bvec, meq = 1, factorized=F)
a   = res$solution
plot(a,type= 'h', main = expression(alpha[i]),
     xlab = expression(i))

# Recover the model:
ww =   t(a*y) %*% z
ww

pad.a     = round(a,3)
wh        = which.max(a)
abline(v=0,h = 0,lty = 2)

# How to find the intercept?..
intercept = (1/y[wh] - ww%*%z[wh,])
yhat = sign(ww %*% t(z) + intercept[1])


# ---- view results -----x
par(mfrow = c(2,2))
plot(x2~x1,pch = c(1,16)[(y+1)/2+1], 
     col= c('darkred','steelblue')[(y+1)/2+1],
     main='True Classes', font.main=1, frame=F)
plot(x2~x1, pch = 16, 
     main='predictions', font.main=1, frame=F,
     col = c('grey','lightblue')[(yhat+1)/2+1])

wh.text = which(pad.a!=0)
points(x2~x1, pch = 1,col = c(NA,'red')[(pad.a>0)+1],cex=2)
text(x2[wh.text]~x1[wh.text],labels = paste0('n = ',wh.text))
plot(y*a,type = 'h')





# --------------------------------- Kernel Trick --------------------------------x



rm(list= ls(all = TRUE))
# Fake some data:
N  = 200

# ---- generate data ----x
x1  = runif(N,-1,1)
x2  = runif(N,-1,1)
X   = cbind(x1,x2)
y   = c(-1,1)[(x2>=x1) + 1] # Encode responses as -1,1
y   = c(-1,1)[(x2^2 + x1^2>=0.8^2) + 1] # Encode responses as -1,1

par(mfrow=c(1,1))
plot(x2~x1,pch = c(1,16)[(y+1)/2+1], 
     col= c('darkred','steelblue')[(y+1)/2+1],
     main='Assuming Linearly Seperable', font.main=1, frame=F)

library('quadprog')
# Create data matrix:
x = cbind(x1,x2)
X <- x




# Some space for the matrix in out QP problem.
DD = X %*% t(X)*0


# ----- kernal -----x
pol = 2
cc = 0
KK <- function(x1,x2) {
  return((cc-t(x1) %*% x2)^pol)
}

# Assign inner products to D
n <- dim(DD)[1]
for (i in 1:n) {
  for (j in 1:n) {
    DD[i,j] = y[i]*y[j]*KK(X[i,], X[j,])
  }
}




# Assign inner products to D


# D inverse is not a friendly chop... So we do what any respectable
# applied mathematician does... We cheat (a little) by adding a small component
# to the diagonal:
eps = 5e-6 
DD  = DD + eps*diag(N)

# Now for the constraints:
# We have quality constraints and inequality constraints:
# Eq  :    y'a = 0
# Ineq:    a >= 0
Amat = cbind(y, diag(N)) # y will be on first row of t(Amat)
bvec = matrix(0, N+1, 1)
d    = matrix(1,N,1)

# Solve for lagrange mults a:
res = solve.QP(DD, d, Amat, bvec, meq = 1, factorized=F)
a   = res$solution
plot(a,type= 'h', main = expression(alpha[i]),
     xlab = expression(i))

 # Recover the model:
# ww =   t(a*y) %*% z
# ww

pad.a     = round(a,3)
wh        = which.max(a)
abline(v=0,h = 0,lty = 2)

# How to find the intercept?..
intercept = y[wh] - sum(a*y*KK(X[wh,], t(X)))
T1 = rep(0,n)
for (i in 1:n) {
  T1[i] = sum(a*y*KK(X[i,], t(x)))
}
yhat = sign(T1 + intercept[1])


# ---- view results -----x
par(mfrow = c(2,2))
plot(x2~x1,pch = c(1,16)[(y+1)/2+1], 
     col= c('darkred','steelblue')[(y+1)/2+1],
     main='True Classes', font.main=1, frame=F)
plot(x2~x1, pch = 16, 
     main='predictions', font.main=1, frame=F,
     col = c('grey','lightblue')[(yhat+1)/2+1])

wh.text = which(pad.a!=0)
points(x2~x1, pch = 1,col = c(NA,'red')[(pad.a>0)+1],cex=2)
text(x2[wh.text]~x1[wh.text],labels = paste0('n = ',wh.text))
plot(y*a,type = 'h')





# -------------- Package solution -----------------x
library('e1071')

dat    = data.frame(y=as.factor(y),x2=x2,x1=x1)
model  = svm(y~., data = dat, kernel ='polynomial',
             gamma=1, coef0=0, degree=2, type = 'C', cost = 20000, scale = F)
par(mfrow=c(1,1))
plot(x2~x1,pch = c(1,16)[(y+1)/2+1])
points(x2~x1, pch = 1,col = c(NA,'red')[(pad.a>0)+1],cex=2)
points(model$SV[,1]~model$SV[,2],pch = '+', col = 'blue',cex = 2)
model
plot(model$coefs~model$index,type = 'h',xlim = c(0,N))

 








# -------------- --------------  Soft Support Vector Machine  -------------- -----------------x
# -------------- -------------- -------------- -------------- -------------- -----------------x


# Non-Linear (+) Non-Separable


# -------------- Simple Non-Separable Data -----------------x
rm(list= ls(all = TRUE))
# Fake some data:
N  = 200

# ---- generate data ----x
x1  = runif(N,-1,1)
x2  = runif(N,-1,1)
X   = cbind(x1,x2)
y   = c(-1,1)[(x2>=x1) + 1] # Encode responses as -1,1


# modify a few points to not be linearly separable
# sample index
near_boundry <- which(abs(x2-x1) < 0.15)
ind <- sample(near_boundry, size=3, replace = F)
for (i in ind) {
  y[i] <- y[i] * -1
}

plot(x2~x1,pch = c(4,4)[(y+1)/2+1], 
     col= c('darkred','steelblue')[(y+1)/2+1],
     main='Assuming Linearly Seperable', font.main=1, frame=F)
points(x2[ind]~x1[ind], pch=16, col='blue')

library('quadprog')
# Create data matrix:
X = cbind(x1,x2)
# Some space for the matrix in out QP problem.
DD = X %*% t(X)*0

# Assign inner products to D
n = dim(DD)[1]
for (i in 1:n) {
  for (j in 1:n) {
    DD[i,j] = y[i]*y[j]*t(X[i,])%*%X[j,]
  }
}


# Assign inner products to D


# D inverse is not a friendly chop... So we do what any respectable
# applied mathematician does... We cheat (a little) by adding a small component
# to the diagonal:
eps = 5e-6
DD  = DD + eps*diag(N)

# Now for the constraints:
# We have quality constraints and inequality constraints:
# Eq  :    y'a = 0
# Ineq:    a >= 0

# ----- New Constraint -----x
C <- 10

Amat = cbind(y, diag(n), diag(n)*-1) 
bvec = matrix(c(rep(0, N+1), rep(-C,N)), N+N+1, 1)
d    = matrix(1,N,1)

# Solve for lagrange mults a:
res = solve.QP(DD, d, Amat, bvec, meq = 1, factorized=F)
a   = res$solution
print(paste0('Number of Support Vectors: ', sum(a>0.001)))






par(mfrow=c(1,1))
plot(a,type= 'h', main = expression(alpha[i]),
     xlab = expression(i), col='steelblue', frame=F, lwd=2)

# Recover the model:
ww =   t(a*y) %*% X
ww
par(mfrow = c(2,2))
par(mfrow = c(1,1))
plot(x2~x1,pch = c(1,16)[(y+1)/2+1])
plot(x2~x1,pch = c(1,16)[(y+1)/2+1], 
     col= c('darkred','steelblue')[(y+1)/2+1],
     main='Assuming Linearly Seperable', font.main=1, frame=F)


pad.a     = round(a, 3)
wh        = which.max(a)
abline(v=0,h = 0,lty = 2)

# How to find the intercept?..
intercept = (1/y[wh] - ww%*%X[wh,])
yhat      = sign(ww%*%t(X) + intercept[1])


# ---- view results -----x
par(mfrow = c(2,2))
plot(x2~x1,pch = c(1,16)[(y+1)/2+1], 
     col= c('darkred','steelblue')[(y+1)/2+1],
     main='True Classes', font.main=1, frame=F)
plot(x2~x1, pch = 16, 
     main='predictions', font.main=1, frame=F,
     col = c('grey','lightblue')[(yhat+1)/2+1])

wh.text = which(pad.a!=0)
points(x2~x1, pch = 1,col = c(NA,'red')[(pad.a>0)+1],cex=2)
text(x2[wh.text]~x1[wh.text],labels = paste0('n = ',wh.text))
plot(y*a,type = 'h')

# -------------- Package Solution --------------x
library('e1071')
# par(mfrow = c(1,1))

dat    = data.frame(y=as.factor(y),x2=x2,x1=x1)
model  = svm(y~., data = dat, kernel ='linear',type = 'C', cost = 10, scale = F)
plot(x2~x1,pch = c(1,16)[(y+1)/2+1])
points(x2~x1, pch = 1,col = c(NA,'red')[(pad.a>0)+1],cex=2)
points(model$SV[,1]~model$SV[,2],pch = '+', col = 'blue',cex = 2)
model


plot(model$coefs~model$index,type = 'h',xlim = c(0,N))





































