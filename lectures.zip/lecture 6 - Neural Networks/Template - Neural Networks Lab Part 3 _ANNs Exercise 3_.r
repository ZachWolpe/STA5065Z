rm(list = ls())
# Define activation functions and their first derivitives. 
# Define the sum-of-squares objective g and its first derivitive w.r.t. the final layer of activations.
sig = function(x)
{
   1/(1+exp(-x))
}
sig. = function(x)
{
  1/(1+exp(-x)) * (1 - 1/(1+exp(-x)))
}
sig2 = function(x)
{
   x
}
sig2. = function(x)
{
   1 + x*0
}
g     = function(yhat,y)
{
	    (yhat - y)^2
}
g.    = function(yhat,y)
{
	    2*(yhat - y)
}
neural_net = function(X,Y,theta,m,lam=0,nu=0)
{

   N = dim(X)[1]
   p = dim(X)[2]
   q = dim(Y)[2]

   index = 1:(p*m)
   w1    = matrix(theta[index],p,m)
   index = max(index)+1:(m*q)
   w2    = matrix(theta[index],m,q)
   index = max(index)+1:(m)
   b1    = matrix(theta[index],m,1)
   index = max(index)+1:(q)
   b2    = matrix(theta[index],q,1)
   

   out   = rep(0,N)
   error = rep(0,N)
   # Define storage for gradient matrices and vectors 
   # ----- store gradients -----x
   dw1 = w1*0
   dw2 = w2*0
   db1 = b1*0
   db2 = b2*0
   
   # for(i in 1:N)
   # {
   #   a0  = cbind(X[i,])
   #   a1  = sig(t(w1)%*%a0+b1)
   #   a2  = sig2(t(w2)%*%a1+b2)
   # 
   #   out[i] = a2
   #   # Evaluate the working gradients:
   #   d2 = g.(a2, y[i]) * sig2.(t(w2)%*%a1+b2)
   #   d1 = (w2 %*% d2) * sig.(t(w1)%*%a0+b1)
   #   
   #   # Evaluate gradient matrices and vectors 
   #   db2 = db2 + d2
   #   db1 = db1 + d1
   #  
   #   dw2 = dw2 + a1 %*% t(d2)
   #   dw1 = dw1 + a0 %*% t(d1)
   #   
   # 
   #   error[i] = (Y[i,] - out[i])^2
   # }
   
   # ======== Matrix Notation =========
   ones = matrix(1,1,N)
   a0  =t(X)
   a1  = sig(t(w1)%*%a0 + b1%*%ones)
   a2  = sig2(t(w2)%*%a1 + b2%*%ones)
   
   out = t(a2)
   # ==== Working Gradients ====
   d2 = g.(a2, t(y)) * sig2.(t(w2)%*%a1+b2%*%ones)
   d1 = (w2 %*% d2) * sig.(t(w1)%*%a0+b1%*%ones)
   
   
   # ==== Accumulate Grads ====
   db2 = d2 %*% t(ones)
   db1 = d1 %*% t(ones)
   
   dw2 = a1 %*% t(d2)
   dw1 = a0 %*% t(d1)
   
   # ---- gradient (INCLUDING REGULARIZATION) ----x
   dw2 = a1 %*% t(d2)  + lam * 2 * w2
   dw1 = a0 %*% t(d1)  + lam * 2 * w1
   # ---- gradient (INCLUDING REGULARIZATION) ----x
   
   error = (y-out)^2

   
   E1    = sum(error)
   E2    = E1 + lam*(sum(w1^2)+sum(w2^2))

   return(list(grad = c(dw1, dw2, db1, db2)/N,
               out = out, E1 = E1/N, E2 = E2/N))
}

# Let's fake a dataset and see if the network evaluates:
set.seed(2019)
N = 250
x = runif(N,-1,1)
y = 2*sin(3*pi*x)+rnorm(N,0,1)
plot(y~x)

X = matrix(x,N,1)
Y = matrix(y,N,1)

p = dim(X)[2]
m = 5
q = dim(Y)[2]

# We need to know the number of parameters in the network:
npars = p*m+m*q+m+q

# Choose some random point in the parameter space and evaluate
# the gradients of the objective function w.r.t. each par:
theta_rand = runif(npars,-2,2)

# neural_net should return the exact gradients:
res = neural_net(X,Y,theta_rand,m)

# Now calculate the approximate gradients:


# ======================= Gradient Testing =======================
lambda = 10
grad_check = c() 
h          = 1/100
for(k in 1:length(theta_rand))
{
	# Define new par vectors:
  theta_plus    = theta_min = theta_rand
  theta_plus[k] = theta_plus[k] + h/2
  theta_min[k]  = theta_min[k] - h/2
	
	# Evaluate cost functions and calc finite difference:
  res_plus = neural_net(X,Y,theta_plus,m,lambda)
  res_min = neural_net(X,Y,theta_min,m,lambda)
	nablak = (res_plus$E1 - res_min$E1)/h
	
	# ---- gradient (INCLUDING REGULARIZATION) ----x
	nablak = (res_plus$E2 - res_min$E2)/h
	# ---- gradient (INCLUDING REGULARIZATION) ----x
	
	
	grad_check[k] = nablak
}

plot(grad_check,pch = 16, col = 'blue')
res = neural_net(X,Y,theta_rand,m,0)
lines(res$grad, type = 'h')




# ======================= Utilizing Gradient Descent =======================
grad_dec = function(theta_start, learn, iterations)
{
  theta         = theta_start
  res           = neural_net(X,Y,theta,m,lambda)
  errors        = rep(0, iterations)
  errors[1]     = res$E1
  theta_mat     = matrix(0, length(theta), iterations)
  theta_mat[,1] = theta
  for (i in 2:iterations) {
    theta  = theta - learn*res$grad
    res    = neural_net(X,Y,theta,m,lambda)
    # ---- graph ----x
    # plot(res$grad, type='h', ylim=c(-1,1)*0.1)
    #  abline(h=c(-1,1)*0.001, lty=3)
    
    errors[i]     = res$E2 
    theta_mat[,i] = theta
  }
  ret = list(theta=theta, errors=errors, theta_mat=theta_mat)
  return(ret)
}

# ======== Optimize Gradient Descent ========
lambda = 1
theta_rand = runif(npars, -2, 2)
res_opt    = grad_dec(theta_rand, 0.1, 50000)


# ======== Plot Errors: Convergence =======
res_opt$theta
plot(res_opt$errors, type='l')


# ======== Plot Parameter Trajectories =======
plot(res_opt$theta_mat[1,], type='n', ylim=range(res_opt$theta_mat),
     main='Parameter Coordinates over Time', font.main=1, frame=F,
     col='darkblue', lty=3)
for (i in 1:length(theta_rand)) {
  lines(res_opt$theta_mat[i,], col='darkblue', lty=3)
}



# ------ Check ------x
# ---- fit ----x
res_fit        = neural_net(X, Y, res_opt$theta, m, lambda)

 # ---- visualized fit: vary regularization ----x
plot(y~x,pch = 1, col = 'lightblue',
     frame=F, main=paste('Neural Net'), font.main=1)
points(res_fit$out~x, col='darkred')


# ======================= Utilizing Gradient Descent =======================







