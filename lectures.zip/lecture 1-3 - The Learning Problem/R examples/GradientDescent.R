library(MASS)

y<-as.integer(Melanoma$status==1)
x<-Melanoma$thickness
seqs<-1:length(y)
y[seqs[y!=1]]<--1 #we need the y's to be either +1 or -1

plot(x,y,xlab="Melanoma Thickness (mm)",ylab="Died from Melanoma?",main="Survival from Malignant Melanoma",cex=0.5)
xx<-seq(0,max(x),0.1)
yy<-exp(-1.6128243+(0.2088352*xx))/(1+exp(-1.6128243+(0.2088352*xx)))
plot(xx,yy,ylim=c(0,1),main="Probability of Death from Melanoma",xlab="Melanoma Thickness (mm)",ylab="Probability",type="l",col="blue")
lines(xx,yy,col="blue")

CrossEntropy=function(x,y,w){
  n<-length(y)
  err<-0
  for(i in 1:n){
    err<-err+(log(1+exp(-1*y[i]*(w[1]+(w[2]*x[i]))))/n)
  }
  return(err)
}

gridder=function(n,xlim,ylim,xdata,ydata){
  x<-seq(xlim[1],xlim[2],(xlim[2]-xlim[1])/(n-1))
  y<-seq(ylim[1],ylim[2],(ylim[2]-ylim[1])/(n-1))
  z<-matrix(data=NA,ncol=n,nrow=n)
  for(i in 1:n){
    for(j in 1:n){
      z[i,j]<-CrossEntropy(xdata,ydata,c(x[i],y[j]))
    }
  }
  dens<-list(x,y,z)
  class(dens)<-"data.frame"
  names(dens)<-c("x","y","z")
  row.names(dens)<-1:n
  return(dens)
}

GradientDescent=function(w0,eta,eps,x,y){
  n<-length(y)
  w=w0
  w.old=w0
  quit=FALSE
  err<-CrossEntropy(x,y,w0)
  while(!quit){
    grad<-c(0,0)
    for(i in 1:n){
      grad[1]<-grad[1]-(1/n)*((y[i]*1)/(1+exp(y[i]*(w.old[1]+(w.old[2]*x[i])))))
      grad[2]<-grad[2]-(1/n)*((y[i]*x[i])/(1+exp(y[i]*(w.old[1]+(w.old[2]*x[i])))))
    }
    w.new<-w.old-(eta*grad)
    w<-rbind(w,w.new)
    if((sqrt(((w.old-w.new)[1]^2)+((w.old-w.new)[2]^2))<eps)|length(err)>10000){quit<-TRUE}
    w.old<-tail(w,1)
    err<-c(err,CrossEntropy(x,y,w.new))
  }
  iterate<-list(err,w)
  names(iterate)<-c("err","w")
  return(iterate)
}

# try eta=0.1, 0.5, 0.9
iter<-GradientDescent(c(0,0),0.9,0.0000001,x,y)
plot(1:200,iter$err[1:200],type="l",xlab="No of iterations",ylab="Error",main=expression("Cross Entropy Error ("~eta~"=0.9)"))
plot(1:length(iter$err),iter$err,type="l",xlab="No of iterations",ylab="Error",main=expression("Cross Entropy Error ("~eta~"=0.5)"))

xlim<-c(-6,2.)
ylim<-c(-0.4,1.0)
d<-gridder(100,xlim,ylim,x,y)
persp(d, phi = 45, theta = 30, shade = .1, border = NA)

image(d,xlab=expression(w[0]),ylab=expression(w[1]),main=expression("Cross Entropy Error ("~eta~"=0.5, steps=327)")); contour(d, add = T)
points(iter$w[,1],iter$w[,2],col="blue",pch=19,lwd=1.2,type="o",cex=0.3)
iter$w[dim(iter$w)[1],]

#note num should be divisble by avgNum
#the last avgNum observations are used to estimate the average Cross Entropy Error
StochasticGradientDescent=function(w0,eta,x,y,num,avgNum){
  n<-length(y)
  inds<-1:n
  w<-matrix(NA,nrow=(num+1),ncol=2)
  w[1,]=w0
  err<-CrossEntropy(x,y,w0)
  k<-1;avg.err<-c()
  for(i in 1:(num/avgNum)){
    for(j in 1:avgNum){
      k<-k+1
      ind<-sample(inds,1)
      grad<-c(0,0)
      grad[1]<-(-1*((y[ind]*1)/(1+exp(y[ind]*(w[(k-1),1]+(w[(k-1),2]*x[ind]))))))
      grad[2]<-(-1*((y[ind]*x[ind])/(1+exp(y[ind]*(w[(k-1),1]+(w[(k-1),2]*x[ind]))))))
      w[k,]<-w[(k-1),]-(eta*grad)
      err<-c(err,CrossEntropy(x,y,w[k,]))
    }
    avg.err<-c(avg.err,mean(err[(k-avgNum+1):(k)]))
  }
  inds<-1:(num/avgNum)
  plot(inds,avg.err,type="l",xlab="time index",ylab="Average Error",main=expression("Average Error over last 1000 iterations ("~eta~"=0.1)"))
  return(w)
}

xlim<-c(-6,2.)
ylim<-c(-0.4,1.0)
d<-gridder(100,xlim,ylim,x,y)

w<-StochasticGradientDescent(c(-6,-0.3),0.1,x,y,100000,1000)
w[dim(w)[1],] #final parameter estimate
image(d,xlab=expression(w[0]),ylab=expression(w[1]),main=expression("Cross Entropy Error ("~eta~"=0.001)")); contour(d, add = T)
points(w[,1],w[,2],col="blue",pch=19,lwd=1.2,type="o",cex=0.3)

