
# Scratch pad


# ------------------------------------------------ Gradient Decent ------------------------------------------------x



rm(list = ls(all = TRUE))
library('plot3D')
# Function:
f = function(x,y,a = 1,b = 10)
{
  (a-x)^2 +b*(y-x^2)^2
}
# Derivatives:
fx =function(x,y,a=1,b=10){-(b*(2*(2*x*(y-x^2)))+2*(a-x))}
fy =function(x,y,a=1,b=10){b*(2*(y-x^2))}

N = 100
x = seq(-3,3,length=N)
y = seq(-1,4,length=N)
xx = rep(x,N)
yy = rep(y,each = N)
Z = matrix(f(xx,yy),N,N,byrow = FALSE)


# ------------------------------------ My Work: Cost Function ------------------------------------x


library(plotly)
fig <- plot_ly(Z = ~ xx + yy, name='Cost Function')
fig <- fig %>% add_surface(Z)
fig

# minimum ----x
print(paste('min Z: ', min(Z)))
print(paste('X that produces min Z:', xx[which(Z==min(Z))]))
print(paste('Y that produces min Z:', yy[which(Z==min(Z))]))
# ------------------------------------ My Work: Functional Form ------------------------------------x



# random starting point (weights) ----x
ind <- sample(1:N, 1)
start_point <- c(x[ind], y[ind])

points(start_point, col='red')


for (i in 1:100) {
  grad <- c(fx(x,y), fx(x,y))
}


colors=c('grey','white','blue')
colpal = colorRampPalette(colors)
gradient_dec = function(x, iter = 10,lamda =0.01,mom = 0)
{
  vals  = rep(0,iter)
  x_est = matrix(0,2,iter)
  stps  = x_est
  vals[1]   = f(x[1],x[2])
  x_est[,1] = x
  
  for(i in 2:iter)
  {
    f. = c(fx(x[1],x[2]),fy(x[1],x[2]))
    dx = -lamda*f.
    x = x + dx+mom*stps[,i-1]
    x_est[,i] = x
    vals[i]   = f(x[1],x[2])
    stps[,i]  = dx
  }
  return(list(fx = vals, x =x_est,dx =stps))
}
res = gradient_dec(c(-0.5,1),200,0.025,0.5)

for(i in 1:dim(res$x)[2])
{
  filled.contour(x,y,Z, main = 'Rosenbrock Function',nlevels = 41,color.palette = colpal,plot.axes = {
    points(1,1,pch = 16,col ='white',cex = 1.5)
    lines(res$x[2,1:i]~res$x[1,1:i],col = 'white')
    lines(res$x[2,(i-1):i]~res$x[1,(i-1):i],type = 'b',pch = 10, col = 'red')
    contour(x,y,Z,levels = round(exp(seq(1,20,length = 11))),add = TRUE,col ='black')
    axis(1); axis(2);
    legend('top', legend =c(paste0('Iteration = ',i),paste0('f(x) = ',round(res$fx[i],7))),bty = 'n')
  })
}























