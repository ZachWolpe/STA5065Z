library(ISLR)

nrow(Auto)

K<-5 #how many folds to use for cross-validation
Q<-9 #upto what degree polynomial do we wish to fit
R<-5 #how many CV curves to plot

plot(Auto$weight,Auto$mpg,xlab="weight (pounds)",ylab="miles per gallon",main="Fuel Efficiency vs Car Weight (1970-1982)")

folds=sample(rep(1:K, length = nrow(Auto)))
folds
table(folds)

#Plot the K-fold cross validated curves
#index r loops over different simulated curves of the 
#index q loops over polynomial fits of different orders
#index i loops over the dataset partitions
K<-10#how many folds to use for cross-validation
Q<-9 #upto what degree polynomial do we wish to fit
R<-5 #how many CV curves to plot
RSS_Q<-matrix(NA,nrow=,R,ncol=Q)
for(r in 1:R){
  folds=sample(rep(1:K, length = nrow(Auto)))
  for(q in 1:Q){
    MSE<-rep(NA,K)
    for(i in 1:K){
      test.ind=(folds==i)
      train.ind=(folds!=i)
      fit<-lm(Auto$mpg[train.ind]~poly(Auto$weight[train.ind],q,raw=TRUE))
      preds<-cbind(rep(1,sum(test.ind)),matrix(poly(Auto$weight[test.ind],q,raw=TRUE),nrow=sum(test.ind),ncol=q))%*%fit$coefficients
      MSE[i]<-sum((Auto$mpg[test.ind]-preds)^2)/sum(test.ind)
    }
    RSS_Q[r,q]<-sum((table(folds)/(nrow(Auto)))*MSE)
  }
}

#Plots the LOOCV curve
K<-nrow(Auto)
folds=sample(rep(1:K, length = nrow(Auto)))
RSS_Q_LOOCV<-c(NA,nrow(Auto))
for(q in 1:Q){
  MSE<-rep(NA,K)
  for(i in 1:K){
    test.ind=(folds==i)
    train.ind=(folds!=i)
    fit<-lm(Auto$mpg[train.ind]~poly(Auto$weight[train.ind],q,raw=TRUE))
    preds<-cbind(rep(1,sum(test.ind)),matrix(poly(Auto$weight[test.ind],q,raw=TRUE),nrow=sum(test.ind),ncol=q))%*%fit$coefficients
    MSE[i]<-sum((Auto$mpg[test.ind]-preds)^2)/sum(test.ind)
  }
  RSS_Q_LOOCV[q]<-sum((table(folds)/(nrow(Auto)))*MSE)
}

sd_CV<-sqrt(RSS_Q)
sd_LOOCV<-sqrt(RSS_Q_LOOCV)

plot(c(0,0),type="n",xlim=c(1,9),ylim=c((min(min(sd_CV),min(sd_LOOCV))-0.5),(max(max(sd_CV),max(sd_LOOCV)))+0.5),xlab="Degree of Polynomial",ylab="Sqrt of MSE",main="10-fold CV")
lines(sd_CV[1,],type="b",col="black")
lines(sd_CV[2,],type="b",col="black")
lines(sd_CV[3,],type="b",col="black")
lines(sd_CV[4,],type="b",col="black")
lines(sd_CV[5,],type="b",col="black")
plot(c(0,0),type="n",xlim=c(1,9),ylim=c((min(min(sd_CV),min(sd_LOOCV))-0.5),(max(max(sd_CV),max(sd_LOOCV)))+0.5),xlab="Degree of Polynomial",ylab="Sqrt of MSE",main="LOOCV")
lines(sd_LOOCV,type="b",col="red")

plot(Auto$weight,Auto$mpg,xlab="weight (pounds)",ylab="miles per gallon",main="Fuel Efficiency vs Car Weight (1970-1982)")
fit<-lm(Auto$mpg~poly(Auto$weight,2,raw=TRUE))
x<-seq(min(Auto$weight),max(Auto$weight),1)
preds<-cbind(rep(1,length(x)),matrix(poly(x,2,raw=TRUE),nrow=length(x),ncol=2))%*%fit$coefficients
lines(x,preds,type="l",col="blue",lwd=2)
