rm(list = ls(all = TRUE))
# Melvin's code:
library(MASS)

y             = as.integer(Melanoma$status==1)
x             = Melanoma$thickness
seqs          = 1:length(y)
y[seqs[y!=1]] = -1 #we need the y's to be either +1 or -1

plot(x,y,xlab="Melanoma Thickness (mm)",ylab="Died from Melanoma?",main="Survival from Malignant Melanoma",cex=0.5)
xx = seq(0,max(x),0.1)
yy = exp(-1.6128243+(0.2088352*xx))/(1+exp(-1.6128243+(0.2088352*xx)))
plot(xx,yy,ylim=c(0,1),main="Probability of Death from Melanoma",xlab="Melanoma Thickness (mm)",ylab="Probability",type="l",col="blue")
lines(xx,yy,col="blue")

# My code:
n = length(y)
f = function(x,y,w)
{
    X = cbind(1,x)
    W = matrix(w,2,1)
    s   = y*(X%*%W)
    Err = 1/n*sum(log(1+exp(-s)))
}
f_grad = function(x,y,w)
{
    X = cbind(1,x)

    W = matrix(w,2,1)
    s   = y*(X%*%W)
    s1  = y*(X[,1])
    s2  = y*(X[,2])
    Err.1 = 1/n*sum(-s1*exp(-s)/(1+exp(-s)))
    Err.2 = 1/n*sum(-s2*exp(-s)/(1+exp(-s)))
    return(c(Err.1,Err.2))
}


y_data  = as.integer(Melanoma$status==1)*2-1
x_data  = Melanoma$thickness

gradient_dec = function(w, iter = 10,lamda =0.01)
{
 vals  = rep(0,iter)
 x_est = matrix(0,2,iter)
 stps  = x_est
 vals[1]   = f(x_data,y_data,w)
 x_est[,1] = w

 for(i in 2:iter)
 {
    f. = f_grad(x_data,y_data,w)
    dx = -lamda*f.
    w = w + dx
    x_est[,i] = w
    vals[i]   = f(x_data,y_data,w)
    stps[,i]  = dx
 }
 return(list(fx = vals, x =x_est,dx =stps,estimate =x_est[,dim(x_est)[2]] ))
}
res = gradient_dec(c(0.0,0.0),200,0.5)
res$estimate


 colors=c('grey','white','blue')
colpal = colorRampPalette(colors)
N = 100
x = seq(-6,2,length=N)
y = seq(-0.4,1,length=N)
Z = matrix(,N,N,byrow = FALSE)
for(i in 1:N)
{
 for(j in 1:N)
 {
    Z[i,j] =  f(x_data,y_data,c(x[i],y[j]))
 }
}

for(i in 1:dim(res$x)[2])
{
filled.contour(x,y,Z, main = 'Cross-Entropy Surface',nlevels = 41,color.palette = colpal,plot.axes = {
points(1,1,pch = 16,col ='white',cex = 1.5)
lines(res$x[2,1:i]~res$x[1,1:i],col = 'white')#type = 'b',pch = 10, col = 'grey')
    lines(res$x[2,(i-1):i]~res$x[1,(i-1):i],type = 'b',pch = 10, col = 'red')
  contour(x,y,Z,levels = ((seq(0,2,length = 11))),add = TRUE,col ='black')
axis(1); axis(2);
legend('top', legend =
  c(paste0('Iteration = ',i),paste0('f(x) = ',round(res$fx[i],7))),bty = 'n')
})
}
