


# -------------- PLA -----------------x
rm(list= ls(all = TRUE))
# Fake some data:
N  = 20

# ---- Generate Data ----x
x1  = runif(N,-1,1)
x2  = runif(N,-1,1)
X   = cbind(x1,x2)
y   = c(-1,1)[(x2>=x1) + 1] # Encode responses as -1,1



# ----- Plot Raw Data -----x
par(mfrow=c(1,1))
plot(x2~x1,pch = c(4,4)[(y+1)/2+1], 
     col= c('darkred','steelblue')[(y+1)/2+1],
     main='Raw Data + Target Function', font.main=1, frame=F, lwd=2)
lines(c(-1,1), c(-1,1), col='green', lwd=2, lty=4)



# ----- Apply PLA -----x
W    <- 0; runif(3)
xplt <- seq(-1,1,length.out = 100)

for (i in 1:100) {
  ind  <- sample(1:20, 1)
  yhat <- sign(W %*% c(1, X[ind,]))
  
  # update
  if (yhat != y[ind]) {
    print('fix')
    W <- W + y[ind] * c(1, X[ind,])
    
    # plot  
    plot(x2~x1,pch = c(4,4)[(y+1)/2+1], 
         col= c('darkred','steelblue')[(y+1)/2+1],
         main=paste0('Run PLA, iter:', i), font.main=1, frame=F, lwd=2)
    
    # compute boundary
    yplt <- -(W[1]*1 + W[2]*xplt) / W[3]
    lines(
      yplt~xplt
      , col='green', lwd=2, lty=4)
    
    Sys.sleep(1)
  }
  

  
  
  
  
  
}


