# Creates a grid for a dividing plane to be plotted in 3D
gridder=function(n,xlim,ylim,a,b){
	x<-seq(xlim[1],xlim[2],(xlim[2]-xlim[1])/(n-1))
	y<-seq(ylim[1],ylim[2],(ylim[2]-ylim[1])/(n-1))
	z<-matrix(data=NA,ncol=n,nrow=n)
	for(i in 1:n){
		for(j in 1:n){
			z[i,j]<-(a*x[i])+(b*y[j])
		}
	}
	dens<-list(x,y,z)
	class(dens)<-"data.frame"
	names(dens)<-c("x","y","z")
	row.names(dens)<-1:n
	return(dens)
}

n<-51;xlim<-c(-10,10);ylim<-xlim;a=1;b=-0.5
classplane<-gridder(n,xlim,ylim,a,b)
zeroplane<-gridder(n,xlim,ylim,0,0)
persp(classplane, phi = 20, theta = 30, shade = .1, border = NA,col=rgb(0, 0, 1, 0.5),xlab=expression(x[1]),ylab=expression(x[2]),zlab=expression(z),main="Classification Plane",d=1,axes=TRUE,ticktype="detailed")
x<-seq(-10,10)
lines (trans3d(x, -10, 0, pmat = res), col = 3,lwd="0.4")
lines (trans3d(x, 10, 0, pmat = res), col = 3,lwd="0.4")
y<-seq(-10,10)
lines (trans3d(10, y, 0, pmat = res), col = 3,lwd="0.4")
lines (trans3d(-10, y, 0, pmat = res), col = 3,lwd="0.4")


points(trans3d(10, -10, 15, pmat = res), col = "red", pch =16)
points(trans3d(-10, 10, -15, pmat = res), col = "red", pch =16)

z<-seq(-15,0)
lines (trans3d(x=0, y=0, z, pmat = res), col = "red",lwd="2")
y<-seq(-15,15)
lines (trans3d(x=0, y, z=0, pmat = res), col = "red",lwd="2")


points(trans3d(8, 2, d$z[((8-(-10))/0.4)+1,((2-(-10))/0.4)+1], pmat = res), col = "red", pch =16)
z<-seq(-15,d$z[((8-(-10))/0.4)+1,((2-(-10))/0.4)+1])
lines (trans3d(x=8, y=2, z, pmat = res), col = "red",lwd="2")
points(trans3d(-10, 4,d$z[((-10-(-10))/0.4)+1,((4-(-10))/0.4)+1], pmat = res), col = "red", pch =16)
z<-seq(-15,d$z[((-10-(-10))/0.4)+1,((4-(-10))/0.4)+1])
lines (trans3d(x=-10, y=4, z, pmat = res), col = "red",lwd="2")
points(trans3d(-6, -9, 0, pmat = res), col = "red", pch =16)
lines (trans3d(x=-6, y=-9, z, pmat = res), col = "red",lwd="2")
points(trans3d(4, 4, 0, pmat = res), col = "red", pch =16)
lines (trans3d(x=4, y=4, z, pmat = res), col = "red",lwd="2")
x<-seq(-10,10)
for(i in -10:10){
	lines (trans3d(x, y=i, z=0, pmat = res), col = 3,lwd="0.4")
}

dd<-gridder(n,xlim,ylim,0.1,0.1)
persp(dd, phi = 10, theta = 30, shade = .1, border = NA)

