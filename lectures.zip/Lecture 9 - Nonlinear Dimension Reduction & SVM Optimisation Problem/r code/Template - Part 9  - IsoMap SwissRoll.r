rm(list= ls())
set.seed(200707881)
install.packages('rgl')
library(rgl)
# options(rgl.useNULL = TRUE)

# ToDo: Generate a shape with increasing radius: (Side-view of Swiss-Roll)
shape = function(N, r=0.1, delta=0.1)
{
  # t = seq(0,2,1/100)
  t = runif(N, 0.5, 2.7)
  x = (r + delta*t)*cos(pi*t)
  y = (r + delta*t)*sin(pi*t)
  z = runif(N)
  return(list(x=x, y=y, z=z))
}
plot(shape(100))

# ToDo: Create observations on a Swiss-Roll like manifold in 3D.
generate = function(N, r= 0.1, delta = 0.1)
{
  t = runif(N, 0.5, 2.7)
  x = (r + delta*t)*cos(pi*t)
  y = (r + delta*t)*sin(pi*t)
  z = runif(N)
  return(list(x=x, y=y, z=z, t=t))
}
dat = generate(500)


# Colour-gradient function to show where on the manifold observations are:





color.gradient = function(x, colors=c('green','yellow','blue'), colsteps=50)
{
  colpal = colorRampPalette(colors)
  return( colpal(colsteps)[ findInterval(x, seq(min(x),max(x), length=colsteps)) ] )
}
rgl.bg(color=c(1,1))
plot3d(dat$x,dat$y,dat$z, col = color.gradient(dat$t))

plot3d(dat$x,dat$y,dat$z, col = color.gradient(dat$t))

# ==== ALT ====
library("scatterplot3d")
scatterplot3d(x=dat$x, y=dat$y,z=dat$z, color.gradient(dat$t))


# Write a function that finds the K-nearest neighbours of each (row) element in X2
# in X1.
k_nn = function(X1,X2,k = 10)
{
  N1 = dim(X1)[1]
  N2 = dim(X2)[1]
  ones = matrix(1, N1, 1)
  inds = matrix(0, N2, k)
  edges = inds
  for (i in 1:N2) {
    dists = sqrt(rowSums((ones %*% X2[i,] - X1)^2))
    wh    = order(dists)[2:(k+1)]
    inds[i,] = wh
    edges[i,] = dists[wh]
  }
  return(list(edges = edges, neighbours = inds, k = k))
}

XX  = cbind(dat$x,dat$y,dat$z)
K   = 7
res = k_nn(XX,XX,K)

# Connect all observations to their 'nearest'  neighbours in our 3D plot:
plt = T
if(plt)
{
 for(i in 1:dim(XX)[1])
 {
      x1 = XX[res$neighbours[i,],1]
      x0 = rep(XX[i,1],K)
      y1 = XX[res$neighbours[i,],2]
      y0 = rep(XX[i,2],K)
      z1 = XX[res$neighbours[i,],3]
      z0 = rep(XX[i,3],K)
      x = matrix(cbind(x0,x1),nrow = 1)
      y = matrix(cbind(y0,y1),nrow = 1)
      z = matrix(cbind(z0,z1),nrow = 1)
     segments3d(x,y,z, col = 'grey')
 }
}


res$edges
library('e1071')

paths = function(res)
{
  N  = dim(res$edges)[1]
  Dg = matrix(Inf, N,N)
  for (i in 1:N) {
    Dg[i,res$neighbours[i,]] = res$edges[i,]
  }
  diag(Dg) = 0
  asp = allShortestPaths(Dg)
  
  for (l in 1:N) {
    Dtemp = Dg
    for (j in 1:N) {
      Dtemp[i,j] = min(Dg[i,j], Dg[i,l] + Dg[l,j])
    }
  }
  Dg = Dtemp
  return(list(Dg = Dg, asp = asp))
}

paths2 = function(res)
{
    N  = dim(res$edges)[1]
    Dg = matrix(Inf, N,N)
    for (i in 1:N) {
      Dg[i,res$neighbours[i,]] = res$edges[i,]
    }
    diag(Dg) = 0
    asp = allShortestPaths(Dg)
    return(list(Dg = asp$length,asp = asp))
}
res2 = paths(res)
res2 = paths2(res)


N = dim(res2$Dg)[1]
D = res2$Dg
S = D^2
H = diag(N)-1/N*matrix(1,N,N)

tau = -0.5*H%*%S%*%H
sv = svd(tau)
plot(sv$d)
plot(sv$u[,2] ~sv$u[,1], col =color.gradient(dat$t),pch = 16)

plt = T
if(plt)
{
 for(i in 1:dim(XX)[1])
 {
      x1 = sv$u[res$neighbours[i,],1]
      x0 = rep(sv$u[i,1],K)
      y1 = sv$u[res$neighbours[i,],2]
      y0 = rep(sv$u[i,2],K)
     segments(x0,y0,x1,y1,col = 'grey')
 }
}


res3 = extractPath(res2$asp,which.min(sv$u[,1]), which.max(sv$u[,1]))
lines(sv$u[res3,2]~sv$u[res3,1],col = 'red', lwd = 3)

 lines3d(dat$x[res3],dat$y[res3],dat$z[res3], col = 'red',lwd = 3)

 