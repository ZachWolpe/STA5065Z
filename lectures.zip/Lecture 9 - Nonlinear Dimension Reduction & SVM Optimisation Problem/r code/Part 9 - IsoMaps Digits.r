rm(list= ls())
train = read.csv('./Machine Learning/Lecture 9 - Nonlinear Dimension Reduction & SVM Optimisation Problem/r code/Train_Digits_20171108.csv')
library(rgl)

x_train=  as.matrix((train[,-1])/255)

y_train=  train[,1]

set = which(y_train ==2)#which(y_train%%2 ==0)[1:200]
X  =  x_train[set,]

image(matrix(X[1,],28,28))


library(colorspace)
color.gradient = function(x, colors=c('green','yellow','blue'), colsteps=50)
{
  colpal = colorRampPalette(colors)
  return( colpal(colsteps)[ findInterval(x, seq(min(x),max(x), length=colsteps)) ] )
}







k_nn = function(X1,X2,k = 10)
{
   N1 = dim(X1)[1]
   N2 = dim(X2)[1]
   d  = dim(X1)[2]
   ones  = matrix(1,N1,1)
   inds  = matrix(0,N2,k)
   edges = inds
   for(i in 1:N2)
   {
       dists     = sqrt(rowSums((ones%*%X2[i,] -X1)^2))
       wh        = order(dists)[2:(k+1)]
       inds[i,]  = wh
       edges[i,] =dists[wh]
   }
   return(list(edges = edges, neighbours = inds, k = k))
}


K = 20
res = k_nn(X,X,K)



library('e1071')

paths = function(res)
{
    N    = dim(res$edges)[1]
    Dg   = matrix(Inf,N,N)
    # Initialize Dg
    for(i in 1:N)
    {
         Dg[i,res$neighbours[i,]] = res$edges[i,]
    }
    diag(Dg) = 0
    asp = allShortestPaths(Dg)
    # Calc paths:
     for(l in 1:N)
     {
      Dtemp = Dg
      for(i in 1:N)
      {
       for(j in 1:N)
       {
         Dtemp[i,j] = min(Dg[i,j],Dg[i,]+Dg[,j])
      }
      }
      Dg = Dtemp
     }

    return(list(Dg = Dg, asp = asp))
}
paths2 = function(res)
{
    N    = dim(res$edges)[1]
    Dg   = matrix(Inf,N,N)
    # Initialize Dg
    for(i in 1:N)
    {
         Dg[i,res$neighbours[i,]] = res$edges[i,]
    }
    diag(Dg) = 0
    asp = allShortestPaths(Dg)
    return(list(Dg = asp$length,asp = asp))
}
res2 = paths2(res)
#spheres3d(XX[c(1,2),1],XX[c(1,2),2],XX[c(1,2),3],col = 'red',radius = 0.01)
#res2[[1]]-res2[[2]]$length

N = dim(res2$Dg)[1]
D = res2$Dg
S = D^2
H = diag(N)-1/N*matrix(1,N,N)

tau = -0.5*H%*%S%*%H
sv = svd(tau)
plot(sv$d)
plot(sv$u[,2] ~sv$u[,1], col =color.gradient(y_train[set]),pch = 16)



plt = F
if(plt)
{
 for(i in 1:dim(X)[1])
 {
      x1 = sv$u[res$neighbours[i,],1]
      x0 = rep(sv$u[i,1],K)
      y1 = sv$u[res$neighbours[i,],2]
      y0 = rep(sv$u[i,2],K)
     segments(x0,y0,x1,y1,col = 'grey')
 }
}


color.gradient2 = function(x, colors=c('green','yellow','blue'), colsteps=50)
{
  colpal = colorRampPalette(colors)
  return( rgb(68/255,119/255,170/255,alpha = seq(0,1,length = colsteps)^2)[ findInterval(x, seq(min(x),max(x), length=colsteps)) ] )
}
color.gradient2 = function(x, colors=c('green','yellow','blue'), colsteps=50)
{
  colpal = colorRampPalette(colors,alpha=TRUE)
  return( colpal(colsteps)[ findInterval(x, seq(min(x),max(x), length=colsteps)) ] )
}
M  = 4
LL = order(sv$u[,1])[1:M]
RR = rev(order(sv$u[,1]))[1:M]
TT = order(sv$u[,2])[1:M]
BB = rev(order(sv$u[,2]))[1:M]
MM = which(sv$u[,1]==median(sv$u[,1]))

res3 = extractPath(res2$asp, LL[1], RR[1])
lines(sv$u[res3,2]~sv$u[res3,1],col = 'grey')

xx = rep(seq(0,1,length = 28),28)/60
yy = rep(seq(0,1,length = 28),each = 28)/60

for(i in 1:M)
{
  points(xx+sv$u[LL[i],1],yy+sv$u[LL[i],2],col = color.gradient2(X[LL[i],]),pch = 15)
  points(xx+sv$u[RR[i],1],yy+sv$u[RR[i],2],col = color.gradient2(X[RR[i],]),pch = 15)
  points(xx+sv$u[TT[i],1],yy+sv$u[TT[i],2],col = color.gradient2(X[TT[i],]),pch = 15)
  points(xx+sv$u[BB[i],1],yy+sv$u[BB[i],2],col = color.gradient2(X[BB[i],]),pch = 15)
}

  points(xx+sv$u[MM,1],yy+sv$u[MM,2],col = color.gradient2(X[MM,]),pch = 15)

plot3d( sv$u[,1],sv$u[,2],sv$u[,3],col =color.gradient(y_train[set]))

library("scatterplot3d")
par(mfrow=c(1,1))
scatterplot3d(x=sv$u[,1],y=sv$u[,2],z=sv$u[,3],color.gradient(y_train[set]))





