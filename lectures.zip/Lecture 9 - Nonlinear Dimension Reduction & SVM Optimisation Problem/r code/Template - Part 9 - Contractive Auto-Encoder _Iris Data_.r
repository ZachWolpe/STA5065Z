rm(list = ls())
set.seed(2001)
sig = function(x)
{
   tanh(x)
}
sig2 = function(x)
{
  x
}

neural_net = function(X,Y,theta,m,lam)
{
   N = dim(X)[1]
   p = dim(X)[2]
   q = dim(Y)[2]

   dims = c(p,m,q)

   index = 1:(dims[1]*dims[2])
   W1    = matrix(theta[index],dims[1],dims[2])
   index = max(index)+1:(dims[2]*dims[3])
   W2    = matrix(theta[index],dims[2],dims[3])
   index = max(index)+1:(dims[3]*dims[4])
   W3    = matrix(theta[index],dims[3],dims[4])
   index = max(index)+1:(dims[4]*dims[5])
   W4    = matrix(theta[index],dims[4],dims[5])

   index = max(index)+1:(dims[2])
   b1    = matrix(theta[index],dims[2],1)
   index = max(index)+1:(dims[3])
   b2    = matrix(theta[index],dims[3],1)
   index = max(index)+1:(dims[4])
   b3    = matrix(theta[index],dims[4],1)
   index = max(index)+1:(dims[5])
   b4    = matrix(theta[index],dims[5],1)

   ones = matrix(1,1,N)
   a0 = t(X)

   # ToDo: Evaluate the updating equation in matrix form
   a1 = sig(t(W1)%*%a0+b1%*%ones)
   a2 = sig(t(W2)%*%a1+b2%*%ones)
   a3 = sig(t(W3)%*%a2+b3%*%ones)
   a4 = sig2(t(W4)%*%a3+b4%*%ones)

   encoded = t(a2)
   # ToDO: Evaluate error function and return encoded data
   error = (t(a4) - Y)^2
   E1 = sum(error)/N
   E2 = E1 + lam/N*(sum(W1^2)+sum(W2^2)+sum(W3^2)+sum(W4^2))
   return(list(encoded = encoded, E1 = E1, E2 = E2))
}


data("iris")
X     = iris[,-5]
Y     = matrix(iris[,5],ncol = 1)
N     = 100
index = sample(1:150,N,replace = F)

Xtrain = as.matrix(X[index,])

# --- scaling ---x
mns    = apply(Xtrain,2,mean)
sds    = apply(Xtrain,2,sd) 
ones   = matrix(1,N,1)
Xtrain = (Xtrain-ones%*%mns)/(ones%*%sds)

# --- predict input ---x
Ytrain = Xtrain
Xtrain = Xtrain#+matrix(rnorm(N*4,0,0.1),N,4)

# --- validation set ---x
Xval   = X[-index,]
Xval   = (Xval-ones%*%mns)/(ones%*%sds)
Yval   = Xval

# --- parameters ---x
p = dim(X)[2]
q = dim(X)[2]
m = c(3,2,3)

# ToDo: Function to evaluate number of parameters in multi-layer network:
npar = function(d)
{
     nd = length(d)
     return(sum(d[-nd]*d[-1]) + sum(d[-1]))
}
d = c(p,m,q)
npar(d)


# ToDo: Objective function
lambda = 0.001
obj = function(pars)
{
   res = neural_net(Xtrain,Ytrain,pars,m,lambda)
   return(res$E2)
}


res1 = nlm(obj,runif(npar(d),-1,1),iterlim = 1500)
res2 = neural_net(Xtrain,Xtrain,res1$estimate,m,lambda)

# --- vis lower dim representation ---x
plot(res2$encoded, col = as.numeric(factor(Y[index])),pch = 16)

SIG = 1/N*(Xtrain%*%t(Xtrain))
sv  = eigen(SIG)
plot(c(sv$vectors[,2]*sqrt(sv$values[1]))~c(sv$vectors[,1]*sqrt(sv$values[2])),col = as.numeric(factor(Y[index])), pch = 16)

