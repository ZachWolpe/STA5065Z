rm(list = ls())

# Let's fake a dataset and see if the network evaluates:
set.seed(2019)
N = 50
x = runif(N,-1,1)
y = 2*x+sin(3/2*pi*x)+1*rnorm(N,0,1/5)
plot(y~x, pch = 16)

# Get the data in matrix form:
X = matrix(x, ncol =1)
Y = matrix(y, ncol = 1)


# Specify activation functions for the hidden and output layers:
sig1 = function(x)
{
  tanh(x)
}
sig2 = function(x)
{
  x
}

# Write a function that evaluates the neural network (forward recursion):
# X     - Input matrix (N x p)
# Y     - Output matrix(N x q)
# theta - A parameter vector (all of the parameters)
# m     - Number of nodes on hidden layer
# lam   - Regularisation parameter (see later)
neural_net = function(X,Y, theta, m, lam = 0)
{
	 # Relevant dimensional variables:
   N = dim(X)[1]
   p = dim(X)[2]
   q = dim(Y)[2]
   
   # Populate weight-matrix and bias vectors:
   index = 1:(p*m)
   W1    = matrix(theta[index], p, m)
   index = max(index)+1:(m*q)
   W2    = matrix(theta[index], m, q)
   index = max(index)+1:(m)
   b1    = matrix(theta[index],m,1)
   index = max(index)+1:(q)
   b2    = matrix(theta[index],q,1)
   
   # Evaluate network:
   out   = rep(0,N)
   error = rep(0,N)
   ones  = matrix(1,1,N)
   #for(i in 1:N)
   #{
      A0  = t(X)
      A1  = sig1(t(W1)%*%A0+b1%*%ones)
      A2  = sig2(t(W2)%*%A1+b2%*%ones)
      out = t(A2)
      error = (Y-t(A2))^2
   #}

   # Calculate error:
   E1 = mean(error)
   E2 = E1+lam/N*(sum(W1^2)+sum(W2^2))
   
   # Return predictions and error:
   return(list(out = out, E1 = E1, E2 = E2))
}

# We need to know the number of parameters in the network:
p          = dim(X)[2]
q          = dim(Y)[2]
m          = 4
npars      = p*m+m*q+m+q
theta_rand = runif(npars,-1,1)
res = neural_net(X,Y,theta_rand,m,0)

plot(y~x,pch = 16,col = 'blue')
points(res$out~x,pch = 16, col = 'red')
legend('topright',c('Y','Predictions'), pch = 16, col = c('blue','red'))


#obj = function(pars)
#{
#  res = neural_net(X,Y,pars,m,0)
#  return(res$E2)
#}
#obj(theta_rand)

#res_opt = nlm(obj,theta_rand, iterlim = 500)
#res_opt


#res_fit = neural_net(X,Y,res_opt$estimate,m,0)

#plot(y~x,pch = 16,col = 'blue')
#points(res_fit$out~x,pch = 16, col = 'red')

XX  = matrix(seq(-1,1,length =100),ncol = 1)
YY  = XX*0
#res_fit2 = neural_net(XX,YY,res_opt$estimate,m,0)
#lines(res_fit2$out~XX[,1])

# Conduct a validation analysis:

set        = sample(1:N,N*0.8,replace = F)
X_train    = matrix(X[set,],ncol = 1)
Y_train    = matrix(Y[set,],ncol = 1)
X_val      = matrix(X[-set,],ncol = 1)
Y_val      = matrix(Y[-set,],ncol = 1)

lambda = 0
obj = function(pars)
{
  res = neural_net(X_train,Y_train,pars,m,lambda)
  return(res$E2)
}
obj(theta_rand)

M_seq   = 25
Train_E = rep(NA,M_seq)
Val_E   = rep(NA,M_seq)
lam     = exp(seq(-7,-1,length = M_seq))
for(i in 1:M_seq)
{
	# Optimise for constraint lam[i]
	lambda = lam[i]
	
  theta_rand = runif(npars,-0.2,0.2)
  res_opt = nlm(obj,theta_rand, iterlim = 500)
  res_1   = neural_net(X_train,Y_train,res_opt$estimate,m,0)
  res_2   = neural_net(X_val,Y_val,res_opt$estimate,m,0)
	# Calculate Validation Error:
  Train_E[i] = res_1$E1
  Val_E[i]   = res_2$E1
  print(paste0('lambda_',i))
}
	
plot(Val_E~lam, type = 'l',col = 4, ylim = c(0,max(Val_E)))


#=============================================
# Cross validation continues here...
#=============================================

# Generate a test set:
x2 = runif(N,-1,1)
y2 = 2*x+sin(3/2*pi*x)+1*rnorm(N,0,1/5)
X_test    = matrix(x2,ncol = 1)
Y_test    = matrix(y2,ncol = 1)
# Cross-Validation

# Set up storage:
K       = 5
M_seq   = 10
Train_E = matrix(NA, K, M_seq)
Val_E   = matrix(NA, K, M_seq)
Test_E  = matrix(NA, K, M_seq)
lam     = exp(seq(-7,-1,length.out = M_seq))





# Double loop:
N_sub = N/K
set   = 1:N_sub
for (j in 1:K) {
  # for each fold
  print(set)
  X_train = matrix(X[-set,], ncol=1)
  Y_train = matrix(Y[-set,], ncol=1)
  X_val = matrix(X[set,], ncol=1)
  Y_val = matrix(Y[set,], ncol=1)
  for (i in 1:M_seq) {
     
    # Optimise for constraint lam[i]
    lambda = lam[i]
    
      theta_rand = runif(npars,-0.2,0.2)
      res_opt = nlm(obj,theta_rand, iterlim = 500)
      res_1   = neural_net(X_train,Y_train,res_opt$estimate,m,0)
      res_2   = neural_net(X_val,Y_val,res_opt$estimate,m,0)
      res_3   = neural_net(X_test,Y_test,res_opt$estimate,m,0)
      
      # Calculate Validation Error:
      Train_E[j,i] = res_1$E1
      Val_E[j,i]   = res_2$E1
      Test_E[j,i]  = res_3$E1
      print(paste0('Fold:', j, 'lambda_', i))
      
      plot(y[-set]~X[-set], pch=10, col='blue')
      plot(y[set]~X[set], pch=10, col='red', cex=1)
      res_fit = neural_net(XX,YY,res_opt$estimate, m, 0)
      lines(res_fit$out~XX, col='steelblue')
      segments(X_val, Y_val, X_val, res_2$out)
      
    
  }
  set = set + N_sub
}


 # Plot CVE:
VE = apply(N_sub/N*Val_E,2,sum)
VE
TE = apply(Test_E,2,mean)
TE
par(mfrow = c(1,1))
plot(VE~lam, type = 'l', lwd = 3, col = 'red',ylim = range(Val_E))
for(j in 1:K)
{
 lines(Val_E[j,]~lam)
}
lines(TE~lam, lty = 2, col = 'magenta')

# Final Hypothesis? 
	lambda = lam[which.min(VE)]
	obj2 = function(pars)
{
  res = neural_net(X,Y,pars,m,lambda)
  return(res$E2)
}
  theta_rand = runif(npars,-0.2,0.2)
  res_opt = nlm(obj2,theta_rand, iterlim = 500)
# res_3   = neural_net(X_test,Y_test,res_opt$estimate,m,0)
# plot(res_3$out~X_test)
