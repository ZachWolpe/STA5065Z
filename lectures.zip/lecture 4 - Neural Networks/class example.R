

# =========================================== IRIS ANN ===========================================
# Load the neuralnet package:
library(neuralnet)

# Load the iris dataset:
data(iris)

X = model.matrix(Species~.,data = iris)[,-1]
Y = matrix(0, dim(X)[1], 3)
Y[1:50,1] = 1
Y[1:50+50,2] = 1 
Y[1:50+100,3] = 1

colnames(Y) = paste0('Y', 1:3)
colnames(X) = paste0('X', 1:4)
data_set = data.frame(cbind(X,Y))

# Fit a neural network:
model1 = neuralnet(Y1+Y2+Y3~X1+X2+X3+X4, data_set, hidden = 3)
# Plot the network architecture:
plot(model1)



# =========================================== sin(x) + e Data Generating Process ANN ===========================================

# Fake some data...
N = 100
x = runif(N,-1,1)
y = 2*sin(3*pi*x)+rnorm(N,0,0.3) 
dat = cbind(x,y)
colnames(dat) = c('X1', 'Y1')
plot(y~x, col='darkblue', frame=F)

res = neuralnet(Y1~X1, data=dat, hidden = c(5), threshold=0.01, err.fct="sse", linear.output=T)
plot(res)

# Check predictions over a discrete lattice and plot: 
x1 = seq(-1, 1,1/100)
XA = cbind(x1)
colnames(XA) = paste0('X1')
pred = compute(res,XA) 
# Plot observed data: 
plot(y~x)

# Superimpose predictions: 
lines(pred$net.result~x1)



# =========================================== Dvc : how much data? ===========================================


pseudo <- function(d, N) {
  N^d * exp(-N)
}

N <- seq(0, 25, length.out=100)
y <- pseudo(4, N)
plot(N, y, 'l', col='darkblue', ylim = c(0,25), xlim = c(0,25), frame=F)
y2 <- pseudo(5, N)
lines(N, y2, 'l', col='darkgreen')


plot(N, log(y), 'l', col='darkblue', ylim=c(log(0.000000001), 10), xlim = c(0,200),frame=F)
lines(N, log(y2), 'l', col='darkgreen')
y3 <- pseudo(15, N)
lines(N, log(y3), 'l', col='darkred')



