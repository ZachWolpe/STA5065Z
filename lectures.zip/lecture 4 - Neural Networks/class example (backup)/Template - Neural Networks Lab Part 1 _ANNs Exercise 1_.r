rm(list = ls())

# Let's fake a dataset and see if the network evaluates:
set.seed(2020)
N = 50
x = runif(N,-1,1)
y = 2*sin(3*pi*x)+rnorm(N)
plot(y~x, pch = 16)

# Get the data in matrix form:
X = matrix(x, ncol = 1)
Y = matrix(y, ncol = 1)


# Specify activation functions for the hidden and output layers:
sig1 = function(x)
{
   tanh(x) #1/(1+exp(x))
}

sig2 = function(x)
{
   x
}

# Write a function that evaluates the neural network (forward recursion):
# X     - Input matrix (N x p)
# Y     - Output matrix(N x q)
# theta - A parameter vector (all of the parameters)
# m     - Number of nodes on hidden layer
# lam   - Regularisation parameter (see later)
neural_net = function(X, Y, theta, m, lam = 0)
{
	 # Relevant dimensional variables:
   N = dim(X)[1]
   p = dim(X)[2]
   q = dim(Y)[2]
   
   # Populate weight-matrix and bias vectors:
   index = 1:(p*m)
   w1    = matrix(theta[index], p, m)
   index = max(index)+1:(m*q)
   w2    = matrix(theta[index], m, q)
   index - max(index)+1:m
   b1    = matrix(theta[index], m, 1)
   index - max(index)+1:q
   b2    = matrix(theta[index], q, 1)
   
   # Evaluate network:
   out   = rep(0,N)
   error = rep(0,N)
   ones  = matrix(1, 1, N)
   
   
   # for(i in 1:N)
   # {
   #    a0 <- t(X[i,])
   #    a1 <- sig1(t(w1) %*% a0 + b1)
   #    a2 <- sig1(t(w2) %*% a1 + b2)
   #    out[i] <- a2
   #    error[i] <- (Y[i,] - a2)^2
   # }
   
   # matrix notation ----x
   A0 <- t(X)
   A1 <- sig1(t(w1) %*% A0 + b1 %*% ones)
   A2 <- sig1(t(w2) %*% A1 + b2 %*% ones)
   out <- t(A2)
   error <- (Y - t(A2))^2

   # Calculate error:
   E1 = mean(error)                                    # unmodified (unregularized) objective
   E2 = E1 + lam/N * (sum(w1^2) + sum(w2^2))           # modified (regularized) objective
   
   # Return predictions and error:
   return(list(out = out, E1 = E1, E2 = E2))
}

# We need to know the number of parameters in the network:
p <- dim(X)[2]
q <- dim(Y)[2]
m <- 12
npars = p*m + m*q + m + q
theta_rand = runif(npars, -1, 1)

time = proc.time()
for (i in 1:1000) {
   res = neural_net(X,Y,theta_rand,m,0)
}
time = proc.time() - time
time


plot(y~x,pch = 4,col = 'blue', frame=F, main='Neural Network', font.main=3)
points(res$out~x,pch = 4, col = 'red')
legend('topright',c('Y','Predictions'), pch = 16, col = c('blue','red'), box.lwd = 0)



# training:validation set ----x
set     = sample(1:N, 0.8*N, replace = F)
X_train = matrix(X[set,], ncol=1)
Y_train = matrix(Y[set,], ncol=1)
X_val   = matrix(X[-set,], ncol=1)
Y_val   = matrix(Y[-set,], ncol=1)



# objective function (with regularization) ----x
lambda = 2
obj <- function(pars) {
   res <- neural_net(X_train,Y_train,pars,m,lambda)
   return(res$E2)
}




# optimization ----x
res_opt <- nlm(obj, theta_rand, iterlim = 500)
res_fit <- neural_net(X,Y,res_opt$estimate,m,lambda)


M_seq      = 10
Train_E    = rep(NA, M_seq)
Val_E      = rep(NA, M_seq)
lam        = exp(seq(-7, 0, length.out = M_seq))
for (i in 1:M_seq) {
   
   # constraint level lam[i]
   lambda <- lam[i]
   
   # 
   theta_rand = runif(npars, -2, 2)
   res_opt <- nlm(obj, theta_rand, iterlim = 500)
   
   # errors
   res_1 <-  neural_net(X_train,Y_train,res_opt$estimate,m,lambda)
   res_2 <-  neural_net(X_val,Y_val,res_opt$estimate,m,lambda)   
   Train_E[i] = res_1$E1
   Val_E[i] = res_2$E1
   print(i)
   
}


plot(Val_E~lam)

# after optimization ----x
plot(y~x,pch = 4,col = 'blue', frame=F, main='Neural Network', font.main=3)
points(res_fit$out~x,pch = 4, col = 'red')
legend('topright',c('Y','Predictions'), pch = 16, col = c('blue','red'), box.lwd = 0)


xx <- matr

