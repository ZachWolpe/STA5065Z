rm(list = ls())
setwd('~/Desktop')
dat = read.table('ClassA.txt', h = T)
head(dat,5)

X  = data.matrix(dat[,-4])
Y  = data.matrix(dat[,4])

# ----- Visualize the Data -----x
col_list = matrix(NA, nrow = nrow(Y), 1)
col_list[Y == -1] <- 'black'
col_list[Y == +1] <- 'orange'
col_list[Y == -1] <- 'steelblue'
col_list[Y == +1] <- 'darkred'
plot(X[,1], X[,2], col=c(col_list), pch=16, main='Visualize the data', font.main=1)

# ----- Visualize 2 -----x 
#install.packages('plotly')
# devtools::install_github("ropensci/plotly")


library(plotly)
fig <- plot_ly(x =X[,1], y =X[,2], z =X[,3], color= col_list)
fig


# ----- Visualize 3 -----x 
library(scatterplot3d) 
scatterplot3d(X, color = col_list, main='Data')





# ----- Kernel Function -----x
kernel <- function(x1,x2) ((c0 + c1 * t(x1) %*% x2)^p)


# Evaluate Hard-Margin Classifier:
# X = predictors (N x 3)
# Y = responses  (N x 1)
my_svm = function(X,Y, c0=0, c1=1, p=2, kernel=kernel)
{
  # hyperparams
  c0<<-c0; c1<<-c1; p<<-p
  
  require('quadprog')
  # Some space for the matrix in out QP problem.
  n = length(Y)
  DD = matrix(0,n,n)
  
  # ToDo:
  # Assign inner products to D
  
  # ----------- Compute D -----------x
  for (i in 1:n) {
    for (j in 1:n) {
      DD[i,j] = Y[i] * Y[j] * kernel(X[i,], X[j,])
    }
  }
  
  
  # ----------- Trick to avoid numerical issues in D -----------x
  eps = 5e-6 
  DD <- DD + eps*diag(n)

  
  # ToDo:
  # We have equality constraints and inequality constraints:
  # Eq  :    y'a  = 0
  # Ineq:    a   >= 0
  
  # ----------- Define Problem Constraints -----------x
  Amat <- cbind(Y, diag(n))
  bvec <- matrix(0, n+1, 1)
  d    <- matrix(1, n, 1)
  
  
  # ToDo:
  # Solve for lagrange mults a:
  
  # ----------- Solve Quadratic Programming Problem -----------x
  res = solve.QP(DD, d, Amat, bvec, meq = 1, factorized=F)
  a   = res$solution

  
  #ToDo:
  # Evaluate elements from Question:

  # ----------- Solve for b -----------x
  pad.a     = round(a)
  wh        = which.max(a)
  
  # ---- int ----x
  b = intercept = Y[wh] - sum(a*Y* t(kernel(X[wh,], t(X))))
  
  # ---- numerical issues: distribution over b ----x
  # Extra
  # index of support vectors
  # bs <- which(pad.a != 0)
  # b_s <- c()
  # for (bb in bs) {
  #   b_s <- c(b_s, 
  #            Y[bb] - sum(a*Y* t(kernel(X[bb,], t(X))))
  #            )
  # }
  # hist(b_s)


  # ------- prediction ------x
  T1 = rep(0,n)
  for (i in 1:n) {
    T1[i] = sum(pad.a*Y*t(kernel(X[i,], t(X))))

  }
  yhat = sign(T1 + intercept[1])

  
  return(list(a = res$solution, b=b, yhat = yhat, res=res))
}


# ----- call SVM -----x
svm <- my_svm(X, Y, c0 = 0, c1 = 1, p= 2,kernel = kernel)



# =========================== Q2.a.writeup ==========================
# ---- view results -----x
par(mfrow = c(2,2))
plot(X[,2]~X[,1],pch = c(1,16)[(Y+1)/2+1], 
     col= c('darkred','steelblue')[(Y+1)/2+1],
     main='True Classes', font.main=1, frame=F)
plot(X[,2]~X[,1], pch = 16, 
     main='predictions', font.main=1, frame=F,
     col = c('grey','lightblue')[(svm$yhat+1)/2+1])

wh.text = which(svm$a!=0)
points(X[,2]~X[,1], pch = 1,col = c(NA,'red')[(svm$a>0.01)+1],cex=2)
plot(-Y*svm$a,type = 'h', main='Support Vectors', font.main=1)


# -------------- Package solution: for good measure -----------------x
library('e1071')
# dat    = data.frame(y=as.factor(y),x2=x2,x1=x1)
model  = svm(Y~., data = dat, kernel ='polynomial',
             gamma=1, coef0=0, degree=2, type = 'C', cost = 20000, scale = F)
plot(model$coefs~model$index,type = 'h',xlim = c(0,nrow(X)),  main='e1071', font.main=1)





# ---- support vector indices ----x 
print('Support Vectors:')
print(which(svm$a>0.01))


# ---- bias term estimate ----x
paste0('bias term:', svm$b)

# ----- prediction accuracy -----x
table(svm$yhat, Y)
paste0('prediction accuracy: ', sum(Y == svm$yhat)/nrow(X) * 100, '%', sep='')

# ---- generalation (E(out) <=) bound ----x
print(paste('E_out bound:', 7/(nrow(X)-1)))


















# -------------- --------------  Soft Support Vector Machine  -------------- -----------------x
# -------------- -------------- -------------- -------------- -------------- -----------------x


# simply add an additional constraint to keep a <= C
# Note: using the package, we need to thus take the negative

rm(list = ls())
setwd('~/Desktop')
dat = read.table('ClassB.txt', h = T)
head(dat,5)

X  = data.matrix(dat[,-4])
Y  = data.matrix(dat[,4])

# ----- Visualize the Data -----x
col_list = matrix(NA, nrow = nrow(Y), 1)
col_list[Y == -1] <- 'black'
col_list[Y == +1] <- 'orange'
col_list[Y == -1] <- 'steelblue'
col_list[Y == +1] <- 'darkred'
plot(X[,1], X[,2], col=c(col_list), pch=16, main='Visualize the data', font.main=1)

# ----- Visualize 2 -----x 
#install.packages('plotly')
# devtools::install_github("ropensci/plotly")



# ----- Kernel Function -----x
kernel <- function(x1,x2) ((c0 + c1 * t(x1) %*% x2)^p)


# Evaluate Hard-Margin Classifier:
# X = predictors (N x 3)
# Y = responses  (N x 1)
my_svm = function(X,Y, c0=0, c1=1, p=2, kernel=kernel, C=10)
{
  # hyperparams
  c0<<-c0; c1<<-c1; p<<-p
  
  require('quadprog')
  # Some space for the matrix in out QP problem.
  n = length(Y)
  DD = matrix(0,n,n)
  
  # ToDo:
  # Assign inner products to D
  
  # ----------- Compute D -----------x
  for (i in 1:n) {
    for (j in 1:n) {
      DD[i,j] = Y[i] * Y[j] * kernel(X[i,], X[j,])
    }
  }
  
  
  # ----------- Trick to avoid numerical issues in D -----------x
  eps = 5e-6 
  DD <- DD + eps*diag(n)
  
  
  # ToDo:
  # We have equality constraints and inequality constraints:
  # Eq  :    y'a  = 0
  # Ineq:    a   >= 0
  

  
  # ------------------------------------------- New Constraints -------------------------------------------x
  Amat = cbind(Y, diag(n), diag(n)*-1) 
  bvec = matrix(c(rep(0, n+1), rep(-C,n)), n+n+1, 1)
  d    = matrix(1,n,1)
  # ------------------------------------------- New Constraints -------------------------------------------x
  
  # ToDo:
  # Solve for lagrange mults a:
  
  # ----------- Solve Quadratic Programming Problem -----------x
  res = solve.QP(DD, d, Amat, bvec, meq = 1, factorized=F)
  a   = res$solution
  
  
  #ToDo:
  # Evaluate elements from Question:
  
  # ----------- Solve for b -----------x
  pad.a     = round(a)
  wh        = which.max(a)
  
  # ---- int ----x
  b = intercept = Y[wh] - sum(a*Y* t(kernel(X[wh,], t(X))))
  
  
  # ------- prediction ------x
  T1 = rep(0,n)
  for (i in 1:n) {
    T1[i] = sum(pad.a*Y*t(kernel(X[i,], t(X))))
    
  }
  yhat = sign(T1 + intercept[1])
  
  
  return(list(a = res$solution, b=b, yhat = yhat, res=res))
}




# ----- call SVM -----x
svm <- my_svm(X, Y, c0 = 0, c1 = 1, p= 2,kernel = kernel, C=10)






# ------- No. SVs -------x
support_vectors <- which(svm$a>0.01)
print(paste('No. SVs: ', length(support_vectors)))



# ---------- recover weights -----------x
W <- 0
for (i in 1:nrow(X)) {
  if (svm$a[i]>0.01) {
    W <- W + svm$a[i] * Y[i] * X[i,]
  }
}


# ---------- Locate Non-Margin SVs -----------x
non_margin_SVs <- c()
for (sv in support_vectors) {
  if (Y[sv]*(t(W) %*% X[sv,] + svm$b)[1] < 1) {
    non_margin_SVs <- c(non_margin_SVs, sv)
  }
}

print('Non-margin Support Vectors Indices:')
print(non_margin_SVs)

print('Number of Non-margin Support Vectors:')
print(length(non_margin_SVs))


# ----- prediction accuracy on Full Class B dataset -----x
table(svm$yhat, Y)
paste0('prediction accuracy: ', sum(Y == svm$yhat)/nrow(X) * 100, '%', sep='')







# ---------- Predict on FULL Dataset: CLASS A + CLASS B -----------x

# datA = read.table('ClassA.txt', h = T)
# datB = read.table('ClassB.txt', h = T)
# dat_full <- rbind(datA, datB)
# X  = data.matrix(dat_full[,-4])
# Y  = data.matrix(dat_full[,4])
# 
# yhat <- c()
# for (i in 1:nrow(X)) {
#   yhat <- c(yhat, sign(Y[i] * (t(W) %*% X[i,] + svm$b))[1])
# }
# table(yhat, Y)
# 
# 
# # ----- prediction accuracy -----x
# table(yhat, Y)
# paste0('prediction accuracy: ', sum(Y == yhat)/nrow(X) * 100, '%', sep='')











































