#======================================================
# Template code:
rm(list = ls())
setwd("~/Desktop")
dat    = read.csv('Digits2020.csv')

library(e1071)

# e1071::allShortestPaths()

Y  =  dat[,1]
X  =  as.matrix(dat[,-1])

image(matrix(X[1,],28,28))





# A function for finding K nearest neighbours: 
k_nn = function(X1,X2,k = 10)
{
  N1 = dim(X1)[1]
  N2 = dim(X2)[1]
  d  = dim(X1)[2]
  ones  = matrix(1,N1,1)
  inds  = matrix(0,N2,k)
  edges = inds
  for(i in 1:N2)
  {
    dists     = sqrt(rowSums((ones%*%X2[i,] -X1)^2))
    wh        = order(dists)[2:(k+1)]
    inds[i,]  = wh
    edges[i,] =dists[wh]
  }
  return(list(edges = edges, neighbours = inds, k = k))
}

# Calculate K nearest neighbours:
K   = 35
res = k_nn(X,X,K)

# Q1 a)
# A function that calculates 
IsoMap=function(res,d)
{
  ## Your Work Here...
  
  # -------------------- Compute Min Paths --------------------x
  paths = function(res)
  {
    N  = dim(res$edges)[1]
    Dg = matrix(Inf, N,N)
    for (i in 1:N) {
      Dg[i,res$neighbours[i,]] = res$edges[i,]
    }
    diag(Dg) = 0
    asp = allShortestPaths(Dg)
    return(list(Dg = asp$length,asp = asp))
  }
  pt <- paths(res)
  # -------------------- Compute Min Paths --------------------x
  
  
  # -------------------- Compute Embedding --------------------x
  N = dim(pt$Dg)[1]
  D = pt$Dg
  S = D^2
  H = diag(N) - 1/N*matrix(1,N,N)
  tau = -0.5*H%*%S%*%H
  sv = svd(tau)

  
  # Return a list with the embedding in U:
  return(list(U = sv$u[,1:d], Dg = D, d = d))
}


# =====================================================================================

# Q1 b)
# Plot the embedding

# ---- run computation ----x
iso <- IsoMap(res = res, d=2)

# ---- create colour map ----x
col_list = matrix(NA, nrow = nrow(X), 1)
col_list[Y == 3] <- 'black'
col_list[Y == 7] <- 'orange'

# ---- vis ----x
plot(iso$U[,2] ~ iso$U[,1], col =col_list,pch = 16, main='2-dimensional Isomap Embeddings', font.main=1,
     xlab='dim 1', ylab='dim 2')
legend('bottomright', legend = c('3', '7'), col = c('black', 'orange'), box.lwd = 0.1, pch=16)











