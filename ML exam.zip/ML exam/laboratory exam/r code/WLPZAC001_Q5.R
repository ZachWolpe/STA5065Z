

# ----- data generating process -----x
gen_data <- function(x) {
  sin(pi*x) + cos(2*pi*x) + sin(3*pi*x) + cos(5*pi*x)
}
x <- runif(n=20, min=-1.5, 1.5)
x <- x[order(x)]
y <- gen_data(x)
plot(y~x, col='darkred', main='Target (noiseless)', type='line', lty=2, font.main=1, lwd=2, frame=F)



# store
H0s <- c()
H1s <- c()
# ----------- Simulate: 10'000 times -----------x
for (i in 1:10000) {
  # sample 3 datapoints
  ind  <- sample(1:20, 3, replace=F)
  X    <- x[ind]
  Y    <- y[ind]
  data <- data.frame(X,Y)
  
  # fit models
  H0 <- mean(Y)
  H1 <- lm(Y~., data=data)
  
  # store results
  H0s <- c(H0s, H0)
  H1s <- rbind(H1s, H1$coefficients)
}




# ----------- Compute Mean (Average) Models -----------x
H0_gbar <- mean(H0s)
H1_gbar <- colMeans(H1s)


# ----------- H0 bias -----------x
bias_H0 <- function(x) {
  (H0_gbar - gen_data(x))^2
}
bias_h0 <- integrate(f = bias_H0, lower = -1, upper = 1)
bias_h0

# ----------- H1 bias -----------x
bias_H1 <- function(x) {
  ( (H1_gbar[[1]] + H1_gbar[[2]] *x) - gen_data(x))^2
}
bias_h1 <- integrate(f = bias_H1, lower = -1, upper = 1)
bias_h1


# ----------- H0 variance -----------x
var_h0 <- mean((H0s - H0_gbar)^2)
var_h0

# ----------- H1 variance -----------x
ave_vars <- c()
for (i in 1:10000) {
  var_H1 <- function(x) {
    ((H1s[i,1] - H1_gbar[[1]]) + (H1s[i,2] - H1_gbar[[2]]) * x)^2
  }
  var_h1 <- integrate(f=var_H1, lower = -1, upper = 1)
  ave_vars <- c(ave_vars, var_h1$value)
}

# ave var (over D)
var_h1 <- mean(ave_vars)
var_h1



# ------------------ visualization ------------------------x
par(mfrow=c(2,2))

# ---- h0 ----x
plot(y~x, col='darkred', main='H0 (average)', type='line', lty=2, font.main=1, lwd=2, frame=F)
abline(h=H0_gbar, col='lightblue', lwd=3)


# ---- h1 ----x
plot(y~x, col='darkred', main='H1 (average)', type='line', lty=2, font.main=1, lwd=2, frame=F)
lines(x=x, y=H1_gbar[[1]] + H1_gbar[[2]] * x, col='lightblue', lwd=3)



# ---- h0: all runs ----x
plot(y~x, col='darkred', main='H0 (all runs)', type='line', lty=2, font.main=1, lwd=2, frame=F)
abline(h=H0_gbar, col='lightblue', lwd=3)
for (i in 1:10000) {
  abline(h=H0s[i], col='lightblue', lwd=0.5, lty=3)
}

# ---- h1: all runs ----x
plot(y~x, col='darkred', main='H1 (all runs)', type='line', lty=2, font.main=1, lwd=2, frame=F)
lines(x=x, y=H1_gbar[[1]] + H1_gbar[[2]] * x, col='lightblue', lwd=3)
for (i in 1:10000) {
  lines(x=x, y=H1s[[i,1]] + H1s[[i,2]] * x, col='lightblue',lwd=0.5, lty=3)
}














