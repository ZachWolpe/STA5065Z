

rm(list = ls(all = TRUE))
dat_train = read.table('FitnessData_Train.txt', h = TRUE)
dat_val   = read.table('FitnessData_Validate.txt', h = TRUE)
dat_test  = read.table('FitnessData_Test.txt', h = TRUE)
head(dat_train, 5)
head(dat_val, 10)
head(dat_test, 10)



# ------- vis -------x
par(mfrow=c(2,3))
plot(x=dat_train$Road_TT_Pace, y=dat_train$MPace, main='Pace ~ road', font.main=1)
plot(x=dat_train$Trail_TT_Pace, y=dat_train$MPace, main='Pace ~ trail', font.main=1)
plot(x=dat_train$Gender, y=dat_train$MPace, main='Pace ~ gender', font.main=1)
par(mfrow=c(1,1))



#=========================================
# Part (a): 
#=========================================


sigma = function(x)
{
  # Activation for layer 1
  1/(1+exp(-x))
}

sigma2 = function(x)
{
  # Activation for layer 2
  # linear 
  x
}

neural_net = function(X,Y,theta,m,lambda)
{
  # X:      input:    X (n x p)
  # Y:      response: Y (n x q)
  # m:      nodes on the hidden layer 
  # theta:  parameter values
  # lambda: regularization term
  
  N = dim(X)[1]
  p = dim(X)[2]
  q = dim(Y)[2]
  
  
  # ToDo:
  # Populate weights and biases
  index = 1:(p*m)
  W1    = matrix(theta[index], nrow = p, ncol = m)
  index = max(index)+1:(m*q)
  W2    = matrix(theta[index], m, q)
  index = max(index)+1:(m)
  b1    = matrix(theta[index],m,1)
  index = max(index)+1:(q)
  b2    = matrix(theta[index],q,1)
  
  
  # ToDo:
  # Evaluate network forward
  out   = rep(0,N)
  ones  = matrix(1,1,N)

  # ---------------- forward pass ----------------x
  A0  = t(X)
  A1  = sigma(t(W1) %*% A0+b1%*%ones)
  A2  = sigma2(t(W2) %*% A1+b2%*%ones)
  out = t(A2)
  
  
  # ToDo:
  # Calculate objectives and return:
  
  # ---------------- objective function (regularized & unregularized) ----------------x
  E1 = mean((Y-t(A2))^2)
  E2 = E1 + lambda /N *(sum(W1^2) + sum(W2^2))
  
  return(list(out=out, a1=A1, a2=A2, E=E1, E2=E2))
}






# ToDo:
# Calculate number of pars:

# ---- define X, Y ----x
X <- dat_train[,-1]
Y <- as.matrix(dat_train[,1], ncol=1)

# We need to know the number of parameters in the network:
p          = dim(X)[2]
q          = dim(Y)[2]
m          = 3
npars      = p*m+m*q+m+q
theta_rand = runif(npars,-1,1)

# ---------- network specs ----------x
m=3; lambda=0; theta=theta_rand
res = neural_net(X,Y, theta=theta_rand, m=3, lambda = 1)

# no learning
res




# ---- No Regularization: Overfitting ----x
obj = function(pars)
{
  res = neural_net(X,Y, theta = pars, m=3, lambda=1)
  return(res$E)
}
obj(theta_rand)

# test: optimization without regularization
res_opt = nlm(obj, theta_rand, iterlim=1000)
res_opt

# overfit
theta=res_opt$estimate; m=3; lambda=0
res_1 = neural_net(X, Y, theta=res_opt$estimate, m=3, lambda=1)
res_1




#=========================================
# Part (b): 
#=========================================


# ----- Validation: Regularization -----x
# Conduct a validation analysis:

# ---- define X, Y (validation) ----x
X_train <- dat_train[,-1]
Y_train <- as.matrix(dat_train[,1], ncol=1)
X_val   <- dat_val[,-1]
Y_val   <- as.matrix(dat_val[,1], ncol=1)


# ----- define objective -----x
obj1 = function(pars)
{
  res = neural_net(X_train,Y_train, theta=pars, m=m, lambda=lambda)
  return(res$E2)
}

obj1(theta_rand)




# ---------- Train Function -------------x
train_ANN <- function(m=3) {

  
  M_seq   = 10
  Train_E = rep(NA, M_seq)
  Val_E   = rep(NA, M_seq)
  lam     = exp(seq(-7, 1, length=M_seq))
  for(i in 1:M_seq)
  {
    
    # Optimise for constraint lam[i]
    # ---- optimize ----x
    lambda     = lam[i]
    theta_rand = runif(npars,-2, 2)
    res_opt    = nlm(obj1, theta_rand, iterlim=500)
    
    # Calculate Validation Error:
    res_1      = neural_net(X_train, Y_train, theta=res_opt$estimate, m=m, lambda = lambda)
    res_2      = neural_net(X_val, Y_val, theta=res_opt$estimate, m=m, lambda = lambda)
    Train_E[i] = res_1$E
    Val_E[i]   = res_2$E
    print(paste('Iteration: ', i)) 
  }
  
  return(list(Train_E=Train_E, Val_E=Val_E, lam=lam, m=m))
  
}




set.seed(82361129)

# ---------- M=3 -------------x
# hypers
p          = dim(X)[2]
q          = dim(Y)[2]
m          = 3
npars      = p*m+m*q+m+q
theta_rand = runif(npars,-1,1)
ANN_3 <- train_ANN()






# ---------------- M=5 ----------------x
# hypers
p          = dim(X)[2]
q          = dim(Y)[2]
m          = 5
npars      = p*m+m*q+m+q
theta_rand = runif(npars,-1,1)
ANN_5 <- train_ANN(m = 5)






# ---------------- Results ----------------x
print('Assess Convergence: ')
# approx =
ANN_3$Train_E
ANN_5$Train_E


par(mar=c(5,5,5,5)+0.1, las=1)
plot.new()
plot.window(xlim=range(ANN_3$lam), ylim=c(min(ANN_3$Val_E, ANN_5$Val_E), max(ANN_3$Val_E, ANN_5$Val_E)))
plot(ANN_3$Val_E~ANN_3$lam, col = 12, frame=F, # ylim=c(min(ANN_3$Val_E, ANN_5$Val_E), max(ANN_3$Val_E, ANN_5$Val_E))
     ylab='', xlab='', 
     main='Validation Analysis', font.main=1)
lines(ANN_3$Val_E~ANN_3$lam, col = 12, type='l')
abline(v=ANN_3$lam[which.min(ANN_3$Val_E)], col=12, lty=3)
axis(2, col.axis=12)


which.min(ANN_5$Val_E)
plot.window(xlim=range(ANN_5$lam), ylim=c(min(ANN_5$Val_E, ANN_5$Val_E), max(ANN_5$Val_E, ANN_5$Val_E)))
points(ANN_5$Val_E~ANN_5$lam, col = 10, frame=F)
lines(ANN_5$Val_E~ANN_5$lam, col = 10, type='l')
abline(v=ANN_5$lam[which.min(ANN_5$Val_E)], col=10, lty=3)
axis(4, col.axis=10)
legend('topright', legend=c('E_val[3-Net]', 'E_val[5-Net]', 'min (3-net)', 'min (5-net)'), 
       col=c(12,10,12,10), lty=c(1,1,3,3), box.lwd = 0.2)


print(paste0('optimal lambda: ', ANN_5$lam[which.min(ANN_5$Val_E)]))






# ====================================== Q3.C ======================================


# set lambda
lam <- ANN_5$lam[which.min(ANN_5$Val_E)]
m   <- 5
lambda     = lam
theta_rand = runif(npars,-1, 1)
res_opt    = nlm(obj1, theta_rand, iterlim=500)

# fit
res_1       <- neural_net(dat_test, matrix(0, nrow=nrow(dat_test)), theta=res_opt$estimate, m=m, lambda = lambda)
predictions <- res_1$out
pred = data.frame(matrix(predictions, ncol = 1))
write.table(pred,'ML2020_WLPZAC001.csv', quote = F, row.names = F, sep = ',')










# ====================================== Linear Model: For Comparison ======================================
X_train <- dat_train[,-1]
Y_train <- as.matrix(dat_train[,1], ncol=1)
X_val   <- dat_val[,-1]
Y_val   <- as.matrix(dat_val[,1], ncol=1)


# model 
dat <- data.frame(X=X_train, Y=Y_train)
mod <- lm(Y~., data=dat)
summary(mod)

# pred on Validation Set
dat <- data.frame(X=X_val, Y=Y_val)
yhat_vals <- predict.lm(mod,  newdata = dat)

# plot 
par(mfrow=c(1,2))
plot(yhat_vals[order(X_val[,2])]~X_val[,2][order(X_val[,2])], type='line', col='red', frame=F, main='Linear Model: using all predictors', font.main=1)
points(Y_val~X_val[,2])


# single predictor
X_train <- as.matrix(dat_train[,3], ncol=1)
X_val   <- as.matrix(dat_val[,3], ncol=1)

# model 
dat <- data.frame(X=X_train, Y=Y_train)
mod <- lm(Y~., data=dat)
summary(mod)

# pred on Validation Set
dat <- data.frame(X=X_val, Y=Y_val)
yhat_vals <- predict.lm(mod,  newdata = dat)

# plot 
plot(yhat_vals~X_val, type='line', col='red', frame=F, main='Linear Model: using 1 predictor', font.main=1)
points(Y_val~X_val)



