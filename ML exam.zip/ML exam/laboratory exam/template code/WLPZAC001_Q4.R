
rm(list = ls(all = TRUE))
dat_train = read.table('FitnessData_Train.txt', h = TRUE)
dat_val   = read.table('FitnessData_Validate.txt', h = TRUE)
dat_test  = read.table('FitnessData_Test.txt', h = TRUE)
head(dat_train, 5)
head(dat_val, 10)
head(dat_test, 10)





# --------------------------------------- Recreate Model  ---------------------------------------x

sigma = function(x)
{
  # Activation for layer 1
  1/(1+exp(-x))
}

sigma2 = function(x)
{
  # Activation for layer 2
  # linear 
  x
}

neural_net = function(X,Y,theta,m,lambda)
{
  # X:      input:    X (n x p)
  # Y:      response: Y (n x q)
  # m:      nodes on the hidden layer 
  # theta:  parameter values
  # lambda: regularization term
  
  N = dim(X)[1]
  p = dim(X)[2]
  q = dim(Y)[2]
  
  
  # ToDo:
  # Populate weights and biases
  index = 1:(p*m)
  W1    = matrix(theta[index], nrow = p, ncol = m)
  index = max(index)+1:(m*q)
  W2    = matrix(theta[index], m, q)
  index = max(index)+1:(m)
  b1    = matrix(theta[index],m,1)
  index = max(index)+1:(q)
  b2    = matrix(theta[index],q,1)
  
  
  # ToDo:
  # Evaluate network forward
  out   = rep(0,N)
  ones  = matrix(1,1,N)
  
  # ---------------- forward pass ----------------x
  A0  = t(X)
  A1  = sigma(t(W1) %*% A0+b1%*%ones)
  A2  = sigma2(t(W2) %*% A1+b2%*%ones)
  out = t(A2)
  
  
  # ToDo:
  # Calculate objectives and return:
  
  # ---------------- objective function (regularized & unregularized) ----------------x
  E1 = mean((Y-t(A2))^2)
  E2 = E1 + lambda /N *(sum(W1^2) + sum(W2^2))
  
  return(list(out=out, a1=A1, a2=A2, E=E1, E2=E2))
}



# ---- define X, Y (validation) ----x
X_train <- dat_train[,-1]
Y_train <- as.matrix(dat_train[,1], ncol=1)
X_val   <- dat_val[,-1]
Y_val   <- as.matrix(dat_val[,1], ncol=1)


# ----- define objective -----x
obj1 = function(pars)
{
  res = neural_net(X_train,Y_train, theta=pars, m=m, lambda=lambda)
  return(res$E2)
}


# ---- define X, Y ----x
X <- dat_train[,-1]
Y <- as.matrix(dat_train[,1], ncol=1)

# hypers
lambda     = 1.117519
p          = dim(X)[2]
q          = dim(Y)[2]
m          = 5
npars      = p*m+m*q+m+q
theta_rand = runif(npars,-1,1)
set.seed(82361129)

# train
theta_rand = runif(npars,-1, 1)
res_opt    = nlm(obj1, theta_rand, iterlim=500)

# --------------- Get Model ---------------x
network <- neural_net(X, Y, theta=res_opt$estimate, m=m, lambda = lambda)






# --------------------------------------- Approx Gradient ---------------------------------------x
h <- 0.01
x <- X[20,]

Delta_ks <- c()
for (k in 1:p) {
  
  # ---- plus ----x
  x_grad <- x
  x_grad[k] <- x[k] + h/2
  a1_plus   <- neural_net(x_grad, matrix(0),  theta=res_opt$estimate, m=m, lambda = lambda)$out[1]
  
  # ---- minus ----x
  x_grad[k] <- x[k] - h/2
  a1_min    <- neural_net(x_grad, matrix(0),  theta=res_opt$estimate, m=m, lambda = lambda)$out[1]
  
  # ---- change ----x
  Delta_k <- (a1_plus - a1_min) / h
  
  # store
  Delta_ks <- c(Delta_ks, Delta_k)
}

# ---- plot ----x
plot(Delta_ks,type = 'h', main='Parameter Sensitivity', font.main=1, col='steelblue', lwd=4, frame=F)














# =========================================================================================================================
# Question 4.B



# --------------------------------------- Modify Model  ---------------------------------------x


sig = function(x)
{
  1/(1+exp(-x))
}
sig. = function(x)
{
  1/(1+exp(-x)) * (1 - 1/(1+exp(-x)))
}
sig2 = function(x)
{
  x
}
sig2. = function(x)
{
  1 + x*0
}

g     = function(yhat,y)
{
  (yhat - y)^2
}
g.    = function(yhat,y)
{
  2*(yhat - y)
}




neural_net = function(X,Y,theta,m,lambda)
{
  N = dim(X)[1]
  p = dim(X)[2]
  q = dim(Y)[2]
  
  
  index = 1:(p*m)
  W1    = matrix(theta[index], nrow = p, ncol = m)
  index = max(index)+1:(m*q)
  W2    = matrix(theta[index], m, q)
  index = max(index)+1:(m)
  b1    = matrix(theta[index],m,1)
  index = max(index)+1:(q)
  b2    = matrix(theta[index],q,1)
  
  
  out   = rep(0,N)
  ones  = matrix(1,1,N)
  
  # ----- store gradients -----x
  dw1 = W1*0
  dw2 = W2*0
  db1 = b1*0
  db2 = b2*0
  
  # ---------------- forward pass ----------------x
  A0  = t(X)
  A1  = sigma(t(W1) %*% A0+b1%*%ones)
  A2  = sigma2(t(W2) %*% A1+b2%*%ones)
  out = t(A2)
  
  # ==== Working Gradients ====
  ones = matrix(1,1,N)
  d2 = g.(A2, t(Y)) * sig2.(t(W2)%*%A1+b2%*%ones)
  d1 = (W2 %*% d2) * sig.(t(W1)%*%A0+b1%*%ones)
  
  # =================================== additional working Grad =================================== 
  d0 = (W1 %*% d1) 
  
  # final X grad
  X_grad <- d0
  
  
  # ==== Accumulate Grads ====
  db2 = d2 %*% t(ones)
  db1 = d1 %*% t(ones)
  
  dw2 = A1 %*% t(d2)
  dw1 = A0 %*% t(d1)
  
  # ---- gradient (INCLUDING REGULARIZATION) ----x
  dw2 = A1 %*% t(d2)  + lambda * 2 * W2
  dw1 = A0 %*% t(d1)  + lambda * 2 * W1
  # ---- gradient (INCLUDING REGULARIZATION) ----x
  


  
  
  
  # ---------------- objective function (regularized & unregularized) ----------------x
  E1 = mean((Y-t(A2))^2)
  E2 = E1 + lambda /N *(sum(W1^2) + sum(W2^2))
  
  return(list(grad = c(dw1, dw2, db1, db2)/N, X_grad=X_grad, 
              out=out, a1=A1, a2=A2, E=E1, E2=E2))
}











# ---- define X, Y (validation) ----x
X_train <- dat_train[,-1]
Y_train <- as.matrix(dat_train[,1], ncol=1)
X_val   <- dat_val[,-1]
Y_val   <- as.matrix(dat_val[,1], ncol=1)


# ----- define objective -----x
obj1 = function(pars)
{
  res = neural_net(X_train,Y_train, theta=pars, m=m, lambda=lambda)
  return(res$E2)
}


# ---- define X, Y ----x
X <- dat_train[,-1]
Y <- as.matrix(dat_train[,1], ncol=1)

# hypers
lambda     = 1.117519
p          = dim(X)[2]
q          = dim(Y)[2]
m          = 5
npars      = p*m+m*q+m+q
theta_rand = runif(npars,-1,1)
set.seed(82361129)

# train
theta_rand = runif(npars,-1, 1)
res_opt    = nlm(obj1, theta_rand, iterlim=500)

# --------------- Get Model ---------------x
# network <- neural_net(X, Y, theta=res_opt$estimate, m=m, lambda = lambda)





h <- 0.01
x <- X[20,]
net <- neural_net(x, matrix(0), theta=res_opt$estimate, m=m, lambda = lambda)



# ---- plot ----x
par(mfrow=c(1,1))
plot(Delta_ks,type = 'h', main='Parameter Sensitivity', font.main=1, col='steelblue', lwd=4, frame=F, 
     ylim=c(0, max(net$X_grad/10)))
points(net$X_grad/10, main='Parameter Sensitivity', font.main=1, col='red', lwd=4)













