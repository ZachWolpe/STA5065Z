rm(list = ls(all = TRUE))
dat_train = read.table('FitnessData_Train.txt', h = TRUE)
dat_val   = read.table('FitnessData_Validate.txt', h = TRUE)
dat_test  = read.table('FitnessData_Test.txt', h = TRUE)
head(dat_train, 5)
head(dat_val, 10)
head(dat_test, 10)

#=========================================
# Part (a): 
#=========================================


sigma = function(x)
{
   # Activation for layer 1
}

sigma2 = function(x)
{
   # Activation for layer 2
}

neural_net = function(X,Y,theta,d,lambda)
{
   p = dim(X)[2]
   q = dim(Y)[2]
   
   # ToDo:
   # Populate weights and biases
   
   # ToDo:
   # Evaluate network forward
   
   # ToDo:
   # Calculate objectives and return:
   
   return(list(out = out,a1= a1,a2= a2, E=E,E2 = E2))
}


# ToDo:
# Calculate number of pars:

obj = function(pars)
{
   # ToDo:
   # Evaluate objective...
}

#=========================================
# Part (b): 
#=========================================