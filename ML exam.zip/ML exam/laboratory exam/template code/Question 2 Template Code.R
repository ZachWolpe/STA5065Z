rm(list = ls())
dat = read.table('ClassA.txt', h = T)
head(dat,5)

X  = data.matrix(dat[,-4])
Y  = data.matrix(dat[,4])

# Evaluate Hard-Margin Classifier:
# X = predictors (N x 3)
# Y = responses  (N x 1)
my_svm = function(X,Y,...)
{

  require('quadprog')
  # Some space for the matrix in out QP problem.
  n = length(Y)
  DD = matrix(0,n,n)

  # ToDo:
  # Assign inner products to D


  # ToDo:
  # We have equality constraints and inequality constraints:
  # Eq  :    y'a  = 0
  # Ineq:    a   >= 0


  # ToDo:
  # Solve for lagrange mults a:
 
  #ToDo:
  # Evaluate elements from Question:
  
  return(list(a = res$solution, b=b, yhat = yhat, res= res))
}